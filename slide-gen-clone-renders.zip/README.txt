Slide Gen Clone

32 reference boards / 112 slides
All individual slides: 1280 x 720 (16:9), PNG.

slides/ : Full-resolution individual slides, grouped by reference board.
decks/  : Overview images for each reference board.
preview.jpg : Overview of all 32 boards.
manifest.json : Slide titles and original filename mapping.

Photos, device screens and complex graphic backgrounds use solid light-gray placeholders as requested. Some source boards are cropped and some fine print is illegible; only legible content is reproduced. Each board received two visual comparison/correction passes plus one final integrated render review.
