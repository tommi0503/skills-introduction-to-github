# Presentation 5 Clone — 이미지 없는 소스

47개 덱 · 1,057개 독립 슬라이드 · 각 페이지 1280×720.

이미지 파일, 원본 시트, PNG 렌더, 비교 JPG, 설치 의존성과 빌드 산출물을 제외했습니다. 텍스트·도형·차트·표·아이콘·SVG 컴포넌트와 회색 placeholder는 코드로 렌더합니다. 외부 브랜드 표기를 중립 문구로 정리했습니다. 원본 이미지 비교 메뉴는 포함하지 않습니다.

```bash
cd presentation5-clone
npm ci --cache /tmp/presentation5-npm-cache --no-audit --no-fund
npm run build
npm run dev -- --host 127.0.0.1
```

Node.js 24에서 빌드했습니다. 갤러리 `#/`, 덱 `#/deck/p004`, 단일 페이지 `#/slide/p004/s02-01`로 탐색합니다.

전체 브라우저 검사: `npm run verify`. Chromium `/usr/bin/chromium`이 필요합니다. 폰트는 패키지 의존성으로 실제 로드하며, CSS로 조립한 SVG 그래픽은 이미지 파일 없이 유지합니다. 원본 글꼴을 확보하지 못한 일부 텍스트는 실제 로드한 대체 글꼴과 자폭 보정을 사용합니다.

`review/source-only-verification.json`은 이 소스의 별도 production 검사 기록입니다. 이전 이미지 포함 제출본과 검수 자료는 저장소에 별도로 보존합니다.
