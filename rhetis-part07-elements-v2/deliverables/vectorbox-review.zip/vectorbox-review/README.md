# vectorbox review

압축을 푼 뒤 [index.html](index.html)을 엽니다. [GAPS](GAPS.md)와 [검수 기록](review-notes.md), [출처](ORIGINS.md)를 함께 읽습니다. 원본 | 불변 replica | 조립3열은 compare-reassembled/에 있으며, 불변 replica 소스는 Git에 유지합니다. 모든 HTML 의존 파일을 로컬에 동봉했습니다.
