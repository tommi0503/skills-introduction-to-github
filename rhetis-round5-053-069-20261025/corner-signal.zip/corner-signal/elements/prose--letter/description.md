Leadership letter: notched white sheet, large introductory name, hairline divider and two light body paragraphs.

Element-owned vector geometry, editable name/note/figure text, and source-relative positions scale within an aspect-preserving local field. Additional local parts extend the original contract without changing its root.

All cut surfaces, tabs, rules and curved annotations are drawn by CSS faces, clip-path facets or value-driven point connectors. The element markup contains no inline SVG; only empty Lucide icon slots remain.
