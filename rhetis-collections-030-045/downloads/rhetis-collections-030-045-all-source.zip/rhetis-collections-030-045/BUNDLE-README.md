# 전체 컬렉션·복제본 통합 소스

컬렉션6개(요소336종), replica90장과 조립본90장의 HTML/CSS, 모든 fixture·metadata·문서·빌드도구와 실행용폰트를 포함합니다. 슬라이드별 PNG180장과 첫 화면 미리보기도 포함했습니다.

1. 이 폴더에서 `python3 -m http.server 8000 --bind 127.0.0.1` 실행
2. `http://127.0.0.1:8000/` 열기
3. 컬렉션은 `collections/`, 복제본 코드는 `reviews/<name>-review/replica/`, 조립본은 `reviews/<name>-review/reassembled/`에서 확인

검수PDF·원본PNG·비교PNG·요소시트PNG는 별도제공한 검수자료에 있습니다. 비교미리보기는 게시된 이미지로 연결됩니다. 네이티브 HTML 슬라이드와 라이브러리 HTML은 포함된 로컬폰트로 실행할 수 있습니다.

[전체소스·검수자료](https://github.com/tommi0503/skills-introduction-to-github/tree/main/rhetis-collections-030-045)

ZIP 내부 `bundle-manifest.json`에서 모든 포함파일의 SHA-256을 확인할 수 있습니다. 전체미디어 통합 ZIP은 `python tools/build_integrated_zip.py --out ../all-with-review-media.zip`으로 만들 수 있습니다(별도검수자료를 source tree에 받은 뒤 실행).
