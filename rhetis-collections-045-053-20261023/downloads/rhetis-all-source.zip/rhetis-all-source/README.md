# Rhetis 전체 컬렉션·복제본 통합 소스

최종 컬렉션 6개와 각 페이지의 재현본(replica)·라이브러리 조립본(reassembled) 코드를 한 폴더에 통합했습니다.

| 컬렉션 | 원본·재현본·조립본 각각 | 요소 |
|---|---:|---:|
| portico-045 | 1 | 56 |
| cultureweave-046 | 18 | 56 |
| launchrail-048 | 30 | 56 |
| vitreous-050 | 20 | 56 |
| axisfold-052 | 20 | 56 |
| obelisk-053 | 18 | 56 |

## 실행

이 README가 있는 폴더에서 실행하세요. Python 3의 기본 라이브러리만 필요합니다.

```bash
python -m http.server 8000
```

브라우저에서 `http://localhost:8000/index.html`을 엽니다. 컬렉션별 목록에서 107개 재현본·107개 조립본과 라이트·다크 요소 시트를 열 수 있습니다. 페이지 크기는 1280×720입니다.

## 폴더

- `collections/<id>/`: 원본 그대로인 kit·foundation·56개 요소와 모든 fixture
- `reviews/<id>/replica/`: 최종 재현본 HTML·CSS
- `reviews/<id>/reassembled/`: 최종 라이브러리 조립본 HTML·CSS
- `reviews/<id>/collection/`: 페이지의 기존 상대 경로를 보존하는 컬렉션 사본
- `reviews/<id>/assets/`: Lucide 등 실행 리소스와 호스트·글꼴 CSS
- `reviews/<id>/library/`: 바로 열 수 있는 라이트·다크 요소 시트 HTML
- `fonts/`: 모든 허용 글꼴의 실제 파일. 중복 바이너리를 이 폴더에 모았습니다.
- `contract/`: 계약 문서·스키마·타입 단계
- `tools/preview.py`: 원본 계약 미리보기 도구
- `tools/build_preview.py`: HTTP에서도 사용할 수 있도록 생성된 시트의 글꼴 URL만 상대 경로로 바꾸는 래퍼
- `manifest.json`: 파일별 SHA-256과 포함 개수·글꼴 경로 변경 목록

## 요소 시트 다시 생성

```bash
python tools/build_preview.py collections/portico-045 contract/type-steps.json --out light.html
python tools/build_preview.py collections/portico-045 contract/type-steps.json --dark --out dark.html
```

다른 컬렉션은 경로의 이름을 바꾸면 됩니다. 원본 `tools/preview.py`도 그대로 포함했습니다.

## 보존 범위

컬렉션과 재현본·조립본 코드는 최종 배포본과 바이트 단위로 같습니다. 글꼴 바이너리 중복을 없애기 위해 각 `assets/fonts/fonts.css`의 URL만 공통 `fonts/`로 바꿨습니다. 글꼴 파일 자체·화면 CSS·마크업·데이터는 바꾸지 않았습니다. 예전 작업용 생성·패치 스크립트 대신 최종 실행 소스를 제공합니다.

이 파일은 소스 통합 ZIP입니다. 렌더 PNG·PDF와 기존 개별 ZIP은 중복으로 넣지 않았습니다. 비교 PDF와 전체 검수 결과는 [기존 배포 페이지](https://github.com/tommi0503/skills-introduction-to-github/tree/main/rhetis-collections-045-053-20261023)에서 받을 수 있습니다. 각 덱의 디자인 언어와 검수 기록도 이 소스 안에 포함했습니다.
