# Rhetis Round5 · 6개 컬렉션 소스 전용 ZIP

최종 컬렉션6개와 검수 페이지·도구의 텍스트 소스를 모았다. 이미지·PDF·폰트 등 바이너리, 기존 ZIP과 실행 로그는 포함하지 않는다.

- `collections/`: 최종135개 요소, 키트 토큰, foundation, fixture 소스
- `reviews/<collection>/replica/`: 보존된 replica HTML·CSS
- `reviews/<collection>/reassembled/`: 조립본 HTML·CSS
- `reviews/<collection>/library/`: 실제 소스로 동작하는 라이트·다크 시트 HTML
- `tools/`, `build/`: 생성·검수 도구와 작업 기록
- `REPORT.md`, `element-origins.md`, 검수 JSON: 디자인 출처·차이·검증 기록

이미지와 폰트 파일을 제외했으므로 PNG를 참조하는 `preview.html`에서는 미리보기 이미지가 표시되지 않는다. 소스 기반 시트 HTML의 원래 글꼴을 재현하려면 `reviews/<collection>/assets/fonts/fonts.css`가 참조하는 폰트 파일을 별도로 준비해야 한다. 최종 컬렉션 소스는 `collections/`이며 `build/`에는 과거 생성 스크립트도 보존되어 있다.

게시된 PDF는 `element-review-pdfs/README.md`의 GitHub 다운로드 링크로 별도 제공한다. `SOURCE-MANIFEST.json`에서 이 ZIP의 전체 소스 목록·해시를 확인할 수 있다. 기존 제출물과 replica는 수정하지 않았다.
