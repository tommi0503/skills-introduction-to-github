# 소스·다운로드

[검수 미리보기](preview.html) · [변경 보고](REPORT.md) · [새 디자인 출처](element-origins.md)

| 컬렉션 | 소스 ZIP | 검수 ZIP | 키트 | Foundation |
|---|---|---|---|---|
| nocturne | [nocturne.zip](nocturne.zip) | [검수 ZIP](nocturne-review.zip) | [kit.json](collections/nocturne/kit/kit.json) | [CSS](collections/nocturne/foundation/foundation.css) |
| inflexion | [inflexion.zip](inflexion.zip) | [검수 ZIP](inflexion-review.zip) | [kit.json](collections/inflexion/kit/kit.json) | [CSS](collections/inflexion/foundation/foundation.css) |
| diecut | [diecut.zip](diecut.zip) | [검수 ZIP](diecut-review.zip) | [kit.json](collections/diecut/kit/kit.json) | [CSS](collections/diecut/foundation/foundation.css) |
| afterglow | [afterglow.zip](afterglow.zip) | [검수 ZIP](afterglow-review.zip) | [kit.json](collections/afterglow/kit/kit.json) | [CSS](collections/afterglow/foundation/foundation.css) |
| dockside | [dockside.zip](dockside.zip) | [검수 ZIP](dockside-review.zip) | [kit.json](collections/dockside/kit/kit.json) | [CSS](collections/dockside/foundation/foundation.css) |
| confluence | [confluence.zip](confluence.zip) | [검수 ZIP](confluence-review.zip) | [kit.json](collections/confluence/kit/kit.json) | [CSS](collections/confluence/foundation/foundation.css) |
