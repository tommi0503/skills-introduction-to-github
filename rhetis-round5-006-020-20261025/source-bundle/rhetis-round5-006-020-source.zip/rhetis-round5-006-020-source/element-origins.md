# Round5 새 디자인 출처

레플리카의 디자인 인스턴스를 먼저 식별한 뒤 독립 요소로 매핑했다. 반복 인스턴스는 같은 디자인으로 묶었다.

| 컬렉션 | 새 디자인 폴더 | 레플리카 페이지 |
|---|---|---|
| nocturne | `elements/card--media/` | 21 |
| nocturne | `elements/headline--qa/` | 23 |
| inflexion | `elements/callout--paired-banner/` | 09 |
| inflexion | `elements/callout--split-banner/` | 08 |
| inflexion | `elements/chart-area--thirds/` | 13 |
| inflexion | `elements/chart-bar--growth/` | 17 |
| inflexion | `elements/chart-donut--pie/` | 15 |
| inflexion | `elements/chart-donut--three-share/` | 11 |
| inflexion | `elements/concentric--market/` | 06 |
| inflexion | `elements/flowchart--controller/` | 16 |
| inflexion | `elements/flowchart--solution/` | 03 |
| inflexion | `elements/headline--caption/` | 15 |
| inflexion | `elements/headline--conclusion/` | 05 |
| inflexion | `elements/headline--contents/` | 02 |
| inflexion | `elements/headline--display/` | 07, 10, 11, 13, 14, 15, 16, 17, 18, 20 |
| inflexion | `elements/headline--market/` | 06 |
| inflexion | `elements/headline--mission/` | 04 |
| inflexion | `elements/list--reasons/` | 15 |
| inflexion | `elements/pill--ruled/` | 07, 17 |
| inflexion | `elements/prose--annotation/` | 04, 14, 17, 20 |
| inflexion | `elements/prose--small/` | 11, 13, 16, 18 |
| inflexion | `elements/prose--support/` | 06, 07, 10, 15, 17 |
| inflexion | `elements/timeline--phases/` | 18 |
| diecut | `elements/card--arched/` | 06 |
| diecut | `elements/card--catalog/` | 09 |
| diecut | `elements/card--certificate/` | 17 |
| diecut | `elements/card--product/` | 07 |
| diecut | `elements/card--roi/` | 14 |
| diecut | `elements/card--testimonial/` | 16 |
| diecut | `elements/chart-bar--combo/` | 05 |
| diecut | `elements/list--summary/` | 18 |
| diecut | `elements/pill--result/` | 13 |
| diecut | `elements/pill--social/` | 19 |
| diecut | `elements/prose--contactline/` | 18 |
| diecut | `elements/prose--enquiry/` | 19 |
| diecut | `elements/steps--loop/` | 12 |
| afterglow | `elements/headline--section/` | 03 |
| afterglow | `elements/image-frame--near-square/` | 07 |
| afterglow | `elements/list--bullets/` | 03 |
| afterglow | `elements/metric--growth/` | 06 |
| afterglow | `elements/pill--next/` | 03 |
| afterglow | `elements/prose--caption/` | 07 |
| afterglow | `elements/prose--center/` | 09 |
| dockside | `elements/callout--results/` | 20 |
| dockside | `elements/card--bubble-comparison/` | 05 |
| dockside | `elements/card--chat/` | 29 |
| dockside | `elements/card--explanation/` | 24 |
| dockside | `elements/card--feature-note/` | 15 |
| dockside | `elements/card--folder/` | 16 |
| dockside | `elements/card--growth/` | 05 |
| dockside | `elements/card--insight/` | 08 |
| dockside | `elements/card--media-row/` | 18 |
| dockside | `elements/card--screen-flow/` | 12 |
| dockside | `elements/flowchart--summary/` | 21 |
| dockside | `elements/headline--keyword-orbit/` | 07 |
| dockside | `elements/hub--idea/` | 17 |
| dockside | `elements/image-frame--carousel/` | 10 |
| dockside | `elements/image-frame--zoom/` | 14 |
| dockside | `elements/list--check-rect/` | 11 |
| dockside | `elements/list--feature-bands/` | 13 |
| dockside | `elements/list--problem-rows/` | 07 |
| dockside | `elements/person--add/` | 19 |
| dockside | `elements/pill--action-rect/` | 18 |
| dockside | `elements/pill--search/` | 02 |
| dockside | `elements/steps--issue-resolution/` | 25 |
| dockside | `elements/tag--notification/` | 02 |
