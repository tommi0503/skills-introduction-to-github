# 사용자 요청: 라이브러리 계약 완화 공지 + 작업 방식 (round 5)
이전 브리프나 README와 다르면 이 문서가 우선이다. Git 명령 금지. 서브 에이전트 중첩 금지. 한국어 보고.

## 핵심
1. 요소를 replica HTML 소스의 수치에서 만들고 반응형으로 만든다. 수치를 비율로 바꾸고 cqw/cqh와 @container로 최소 칸부터12x6까지 깨지지 않게 한다. 페이지(장면)를 옮기지 않고 요소를 옮긴다. 기존 CSS 위에 덧붙이지 말고 파일을 새로 쓴다.
2. 요소 안의 화살표·연결선·노치·탭은 그 요소 CSS가 그린다. 연결선은 이어진 멤버 전부를 가진 한 요소의 것이다.
3. fixture 글은 새로 쓴다. replica 문구·회사명 금지. 조립 검증 페이지만 replica 문구 허용.
4. 색은 팔레트 토큰만. 글자 크기는 var(--type-N) 또는 clamp(var(--type-A),calc(…),var(--type-B)).
5. 크기별 시트(요소마다,fixture마다 한 줄,칸 크기별)로 매번 보고 바로 고친다.

## 허용
### 1 복수 디자인
- elements/<leaf>/ 외 elements/<leaf>--<design>/ 몇 개든 가능. 예 card/,card--cut/,card--leaf/,card--tonal/.
- design 이름 소문자·숫자·하이픈만, --는 안 됨.
- 각 폴더 독립 요소. 키 <collection>-<leaf>--<design>, fixture data-el과 CSS범위도 이 키.
- description.md 영어로 구체적인 외형 설명(리졸버 선택용).
- 두번째·세번째 디자인은gap아님,새디자인폴더.
### 2 완전성 취소
- 실제로 가진 디자인만 담는다. replica없는 계약을 일반 디자인으로 채우지 않는다.
- 페이지는 여러 컬렉션을 섞어 쓴다.
- registry/states.json의 공통상태fixture선택. 같은id라면데이터문구일치필요.
### 3 자유 클래스
- 요소자신의부품·변형클래스자유:cut/notch/badge/rule/cap등.
- 계약 root, 데이터부품name/note/fig/mark/kick 및값--v의의미를지키고,다른계약root이름과겹치지않기.
- 요소안에같은컬렉션다른요소를넣어도됨. fixture에그data-el키를쓰면의존성.
### 4 foundation panel
다른요소를감싸는틀은foundation .panel로만든다.
<div class="panel" data-slot="…" style="grid-…">
 <div class="bar"><span class="kick">Input</span><b class="name">현황 분석</b></div>
 …요소하나,또는.group/.stack/.split안의요소들…
</div>
- panel/bar의띠색·촉·절단모서리·라운드·세로rule등foundation.css가디자인.
- foundation변형클래스자유:panel.on/line,bar.tip-r.
- 반응형규칙은요소와같음.
### 5 차트 확장
- chart.donut: .donut.pie > .slice ×2–6. 각slice style="--v:N"(합100),.name,<b>값,.slice.on. 가운데.fig선택. 다중조각도넛/파이.
- chart.bar: .bars.grouped > .group ×2–8. 각group <span>라벨 + .bar×2–4(--v,.tone-N). combo는.bars안.line > .pt×n(--v).
- chart.line: .lines > .series×1–4(.tone-N,.name)> .pt.
- 모든차트점·막대·조각안.at(짧은주석)허용. 큰원배지/말풍선/곡선화살표등주석모양은요소소유. y축눈금은--max에서그림.
- positioning.map: .mark에--r(0–100크기),.note(2–3줄)허용. 축라벨1개면축이름.
### 6 큰 타이포와 seat
- 글자토큰8–256px. 217px표제도--type-216등.32이상4px단위.
- seat.wide긴띠/tall세로crop/device기기화면/round원형. 모양foundation소유.
### 7 형태
- 절단모서리,droplet,오각형,리프탭등자유CSS clip-path/mask/border-radius/gradient.
- 공통형태값은요소tokenDefaults(--<collection>-…)나kit확장토큰.

## 엄격한gap기준
- 위에서아래로매핑:페이지마다요소인스턴스를먼저찾아map.json작성. DOM노드를계약에맞춰남은것gap하는방식금지.
- 글자스타일/캡션/라벨/측정값덤프(font=…;size=…)/남은글자조각은절대gap아님. 해당요소타이포또는페이지장치.
- 1–7로도표현불가구체적이유만gap(예멤버계약최대6인데9).
- 반복같은디자인gap한줄합침.
- 페이지전체장식(띠/사선면/큰도형)은gap아닌배경frame/vector.

## 적용순서
1. 기존gap재분류:추가디자인/패널/차트확장/타이포seat선택,잔여물삭제.
2. 풀리는것새designfolder또는foundation panel로새로제작,반응형+크기별시트검수.
3. replica없는일반디자인삭제가능. 남길것만남긴다.
4. 조립페이지다시그려replica비교.
5. 잔여gap구체이유보고.

## 보고(컬렉션마다짧게)
- 추가designfolder목록(폴더←replica페이지)
- panel쓴곳
- 차트확장쓴곳
- 삭제일반요소
- 잔여gap과이유
- 마지막수정뒤실제로열어본시트와비교이미지
