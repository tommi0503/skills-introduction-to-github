# Round5 검수·변경 보고

기존 replica191파일은 바꾸지 않았다. 실제 소스의 디자인만 남겼으며, 추가 디자인과 패널로 이전84개 gap 인스턴스를 재분류했다. **남은 표현 불가 gap은0이며, 원본과 남은 배치·줄바꿈·질감 차이는 각 보고서에 별도로 적었다. 픽셀100% 동일을 주장하는 결과가 아니다.**

| 컬렉션 | 요소 | 새 디자인 | 일반 삭제 | gap | 요소·패널 조건 | 상세 |
|---|---:|---:|---:|---:|---:|---|
| nocturne | 8 | 2 | 50 | 0 | 266 | [6p 보고](reviews/nocturne/round5-report.md) |
| inflexion | 39 | 21 | 38 | 0 | 1566 | [20p 보고](reviews/inflexion/round5-report.md) |
| diecut | 29 | 13 | 40 | 0 | 1638 | [19p 보고](reviews/diecut/round5-report.md) |
| afterglow | 16 | 7 | 47 | 0 | 664 | [9p 보고](reviews/afterglow/round5-report.md) |
| dockside | 40 | 23 | 39 | 0 | 1332 | [30p 보고](reviews/dockside/round5-report.md) |
| confluence | 3 | 0 | 53 | 0 | 90 | [4p 보고](reviews/confluence/round5-report.md) |

**nocturne** — 중앙 광원·빔은 foundation 배경으로, 사진 위 타일과204px 질문 표제는 독립 디자인으로 복원했다. 추가 패널·차트 없음. 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/nocturne/round5-report.md)와 해당 JSON receipt에 있다.

**inflexion** — 시장 산형도·세 종류 표제·배너·원형 차트·제어 흐름·9개 사건 타임라인 등을 분리했다. 차트 면 패널·카드 틀,3조각 파이/도넛,3분할 축,점/선/면 데이터를 사용했다. 원형 비율·축·균일30%면·본문 관통 점선을 수정했다. 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/inflexion/round5-report.md)와 해당 JSON receipt에 있다.

**diecut** — 제품 가로 카드와 세로 카탈로그, 아치·후기·인증 카드, 기울어진 ROI 타원,7단계 순환 등을 분리했다. 제품·시장·KPI·ROI·후기·인증·전체 캔버스 패널과8막대+선 콤보를 사용했다. 사진12px 모서리를 복원했다. 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/diecut/round5-report.md)와 해당 JSON receipt에 있다.

**afterglow** — 176px 표제·140px 수치·작은 점 목록·14px 캡션·중앙 본문·사진 비율·다음 버튼을 분리했다. Process 설명의 ruled 패널과 영역 차트 점이 소유하는3개 화살표를 사용했다. 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/afterglow/round5-report.md)와 해당 JSON receipt에 있다.

**dockside** — 폴더·미디어 행·화면 흐름·확대 사진·아이디어 허브·결과·대화 등 실제 디자인을 분리했다. 6종 패널을 사용했다.04 캡슐 체크 행과11 직사각 체크 행을 독립시켰고, 폴더 사진 창 선택자·아이콘 자리·대비를 수정했다. 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/dockside/round5-report.md)와 해당 JSON receipt에 있다.

**confluence** — 실제3종 요소를 유지하고 프로젝트의 label/value 띠와 카드3개를 foundation 패널로 묶었다. 프로젝트 띠·필드 패널의115:23:433 비율을 복원했다. 새 차트 확장 없음. 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/confluence/round5-report.md)와 해당 JSON receipt에 있다.

요소와 패널은 라이트·다크에서 fixture별 최소 칸부터12×6까지 실제 Chromium으로 렌더했다. 글자 영역 초과·클리핑·폰트 실패·필수 글자 숨김·0크기·실측 대비 문제는 남지 않았다. Diecut의 SUITE 행 상자 접촉6조건은 교차 영역의 실제 글자 픽셀0으로 확인했으며, Confluence 표지의 행 상자 접촉도 독립 글자층의 실제 교집합0으로 확인했다. 기본 foundation 예제도 양 모드1280×720로 열어 보았다.

사진·3D·화면은 요청대로 회색 자리로 두었다. fixture 문구는 새로 작성했고, 검증 조립본만 replica 문구를 사용했다. 기존 replica 제작 때의 판독 불가·보완 문구 기록은 각 검수 ZIP의 `replica-review-notes.md`에 함께 보존했다.

Git 명령 금지 지시에 따라 이번 라운드는 로컬 제출물로 제공한다. GitHub에 새 commit·push를 하지 않았다. 최종 압축 파일은 로컬 HTTP로 다시 내려받아 SHA256·CRC를 검사하며, 결과는 `final-verification.json`에 기록한다.

## 최종 제출물 검사

최종 ZIP12개를 로컬 HTTP로 실제 다시 내려받아 SHA-256 일치와 ZIP CRC 무결성을 확인했다. PDF24개의 페이지 수, PNG3,220개의 크기·무결성,6컬렉션 뷰어 전환과12개 실제 소스 기반 라이트·다크 HTML의 폰트·아이콘 로딩을 확인했다. 조립본88페이지는 모두1280×720이다. 상세 결과는 [final-verification.json](final-verification.json), [png-validation.json](png-validation.json), [최종 통합 검수 영수증](parent-integration-review.json)에 있다.

## 추가 요청: Git 게시와 전체 요소 PDF

사용자의 후속 요청으로 Git 금지 지시는 게시 작업에 대해 변경되었다. 원래 로컬 검수 영수증은 보존하고 새 폴더에 소스·ZIP·검수 자료를 추가한다. 전체135개 요소와 패널·foundation 예제를 포함하는 라이트·다크 통합 PDF를 각155페이지로 만들고 컬렉션·요소별 책갈피를 넣었다. 컬렉션별 PDF12개도 별도 파일명으로 제공한다. 추가 PDF 검증은 `element-review-pdfs/verification.json`, GitHub에서 실제 다시 내려받은 검증은 `github-download-verification.json`에 기록한다.
