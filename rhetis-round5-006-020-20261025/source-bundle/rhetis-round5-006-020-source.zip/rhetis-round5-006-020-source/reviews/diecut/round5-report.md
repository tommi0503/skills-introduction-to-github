# Diecut Round 5 report

동결 SHA256: `a1ff70cd4ef4ad3cc82a356b58fece9c9c7e9e3bbf06187cceb1a126fd7daa75`. collection 소스 29개 디자인, 요소 fixture 92개, 패널 디자인 13개/fixture 26개. 원본 19장, DOM 501개 모두 map에 연결했다. 기존 replica는 불변이다.

## 새 독립 디자인과 원본

| 폴더 | 원본 페이지 |
|---|---|
| `card--arched` | 06 |
| `card--catalog` | 09 |
| `card--certificate` | 17 |
| `card--product` | 07 |
| `card--roi` | 14 |
| `card--testimonial` | 16 |
| `chart-bar--combo` | 05 |
| `list--summary` | 18 |
| `pill--result` | 13 |
| `pill--social` | 19 |
| `prose--contactline` | 18 |
| `prose--enquiry` | 19 |
| `steps--loop` | 12 |

## 패널과 차트

13개 패널: reasons(04), market(05), solutions(06), products(07), catalogs(09), system(11), kpi(13), roi(14), canvas(15), testimonials(16), certificates(17), action(18), social(19). 원자 요소의 데이터·형태는 요소가 소유하고 묶음의 면·배치 관계만 panel이 맡는다. 제품/카탈로그/솔루션 bleed 및 canvas 페이지 프리셋은 실제 foundation body의 할당 영역을 바꾼다. panel root는 자기 칸 100%를 유지한다.

05의 `chart-bar--combo`는 bars와 line을 한 계약으로 결합한다. 원래 시계열 수치와 동일 축을 사용한다. 13의 chart-stack 원래 before/after 수치와 4개 변화 캡슐은 유지한다.

## 삭제한 일반 요소 40개

`architecture`, `balance`, `bullet`, `chart-area`, `chart-bar`, `chart-donut`, `chart-line`, `chart-scatter`, `chart-waterfall`, `code`, `concentric`, `cycle`, `decision-tree`, `delta`, `flowchart`, `funnel`, `gauge`, `heatmap`, `hub`, `journey`, `logo-group`, `matrix`, `matrix-nine`, `metric`, `mindmap`, `network`, `person`, `positioning`, `pricing`, `pyramid`, `quote`, `radar`, `roadmap`, `sankey`, `slope`, `sparkline`, `swimlane`, `treemap`, `venn`, `waffle`.

## 잔여 GAP 및 차이

GAP 0개. 이전의 큰 타이포·caption panel·기울어진 ROI·7단계 열린 루프·계단형 프로세스는 허용된 독립 디자인과 foundation panel로 복원했다. 03/08 정수 그리드 배치, 10/13 작은 note/차트 라벨 크기, 16 긴 문장 줄바꿈, 근사 글꼴 및 허용 이미지 placeholder는 `review-notes.md`에 구체적으로 기록했다.

## 마지막 실제 이미지 검수

확인 UTC: 2026-10-25T05:12:48.791381+00:00. 동결 SHA의 최종 렌더를 직접 열어 본 전체 목록과 파일 경로는 `visual-review.json`에 있다.

- `sheets/*-light.png`, `sheets/*-dark.png`: 현재 29개 요소 전부와 foundation panel 전부. 각 fixture의 선언 min 및 가능한 요구 크기를 확인했다.
- `sheets/*-replica.png`: 29개 요소 전부와 foundation panel 13행. 원본 팔레트의 replica crop | 12×6 | min을 비교했다.
- `compare-reassembled/slide-01.png`부터 `slide-19.png`까지 19장: 원본 | replica | 재조립을 개별 확인했다.

자동검사 수치·대비 실측 여부·PNG 치수·HTML 및 소스 SHA 일치는 `final-checks.json`에 기록한다. 부모가 추가 통합 검수를 수행한다.

최종 대비 실측: 1,638케이스/null0/텍스트Range11,024/실패0. sourceSHA 및 HTML19개 일치. PNG128개 치수 확인. tag Range6건 실제 ink중첩0px. 최종 원자료: `final-checks.json`.

최종 한 속성 보정: 09장 카탈로그 이미지 좌석의 border-radius를 0에서 2.993cqw(원본 401px 카드 폭에서12px)로 복원했다. 다른 collection 기하·문구·데이터는 바꾸지 않았다. 해당 요소·catalogs 패널 및19장과 원본 대조를 다시 렌더했다. 영향 없는 요소는 fixture SHA와 모든 적용 CSS/컨테이너 분기 일치가 증명된 render-reuse 영수증으로 기존 대비 실측 픽셀을 재사용했다. 전체 summary와 source comparison/reassembled 감사는 새 동결SHA이며 개별 캐시의 이전SHA는 영수증과 함께 보존한다.

마지막 모서리 보정 실제 이미지 확인 UTC: 2026-10-25T05:27:27.411919+00:00. card--catalog light/dark/source, 09장 삼중 비교 및 catalogs 패널 light/dark 12×6/min을 새SHA로 다시 확인했다.
