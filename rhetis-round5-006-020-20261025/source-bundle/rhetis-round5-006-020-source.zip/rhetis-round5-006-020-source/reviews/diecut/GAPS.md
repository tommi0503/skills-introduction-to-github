# Remaining unexpressible designs

없음. Round 5의 독립 디자인, foundation panel, 8–256 타입 및 비율 seat 허용으로 이전 15개 GAP을 표현했다. 원본과의 정수 그리드·근사 글꼴 차이는 `review-notes.md`에 따로 기록한다. 사진·복잡한 이미지 아이콘의 허용 placeholder를 표현 불가로 세지 않는다. 이 분류는 픽셀 단위 동일을 의미하지 않는다.
