# Dockside round5

기존37GAP은23개 독립 디자인과6개 foundation panel로 해결했다. 원본에 없는 일반39요소를 삭제했다. 새CSS는 각source의치수에서처음작성했으며旧element.css를복사하거나덧씌우지않았다.

## 추가 디자인

- `tag--notification` ← replica 02
- `card--growth` ← replica 05
- `card--bubble-comparison` ← replica 05
- `headline--keyword-orbit` ← replica 07
- `list--problem-rows` ← replica 07
- `card--insight` ← replica 08
- `image-frame--carousel` ← replica 10
- `card--screen-flow` ← replica 12
- `list--feature-bands` ← replica 13
- `image-frame--zoom` ← replica 14
- `card--feature-note` ← replica 15
- `card--folder` ← replica 16
- `hub--idea` ← replica 17
- `card--media-row` ← replica 18
- `person--add` ← replica 19
- `callout--results` ← replica 20
- `flowchart--summary` ← replica 21
- `card--explanation` ← replica 24
- `steps--issue-resolution` ← replica 25
- `card--chat` ← replica 29
- `pill--action-rect` ← replica 18
- `pill--search` ← replica 02
- `list--check-rect` ← replica 11: P04 capsule과 다른 10px 모서리 glass row

## 패널

- context←04, peek←06, insight-strip←08, feature-board←15, well←18, conversation←29. 각2개새문구fixture.
- photo/device/graphic처럼직접그리지않는자료는foundation seat.wide/device/tall/round로표시한다. 배경대체사진은 .deco.backdrop에실측좌표로놓는page furniture이며page별elementCSS가아니다.

## 차트 확장

- 별도확장없음. 05의원은인쇄비율을보조하는비교카드장식이며면적비차트로주장하지않는다. 20의도넛은기존--v값을유지한다. 21은값없는요약→결과흐름으로flowchart가모든연결과멤버를소유한다.

## 삭제

`architecture`, `balance`, `bullet`, `chart-area`, `chart-bar`, `chart-line`, `chart-scatter`, `chart-stack`, `chart-waterfall`, `code`, `concentric`, `cycle`, `decision-tree`, `delta`, `flowchart`, `funnel`, `gauge`, `heatmap`, `journey`, `legend`, `logo-group`, `matrix`, `matrix-nine`, `metric`, `network`, `positioning`, `pricing`, `pyramid`, `quote`, `radar`, `roadmap`, `sankey`, `slope`, `sparkline`, `swimlane`, `table`, `treemap`, `venn`, `waffle`

## 잔여 GAP

- 없음. 반복캡션/번호/조작/사진조각은소유요소또는panel부품으로map에기록했다. 정수12×6그리드의배치차이는GAP으로늘리지않고검수기록에남긴다.

## 최종 검수

동결 SHA: `d8d270ea37b2549c7332fb342674f93c68ae0611f18dcfd783790eb5ca17cc32`.

- 최종 40요소 / 118 fixture / 패널 6종·12 fixture. 두 모드 크기 검수 1,272조건과 패널 60조건에서 영역 초과·겹침·잘림·폰트·숨김·영크기·실제 glyph 대비 실패 모두 0.
- 정적 오류 0, CSS selector 1005개 중 오류 0, 문구 복제 검사 두 방식 모두 0. 고정형 소형 컨트롤과 본문에 대한 cqw 부재 경고 4건은 실제 크기 검수로 확인했다.
- 재조립 30 PNG 모두 1280×720, 삼중 비교 30 PNG 모두 3840×720. 마지막 assembly 변환에서 P11 우측 chevron 누락을 바로잡은 뒤 전체 30페이지를 다시 렌더했다. 컬렉션 CSS는 바꾸지 않았다.
- 소스 대조 39 PNG / 48행: mapped 요소 38개와 foundation 패널 6종의 대표 표본이다. 독립 사용이 남아 있는 person과 tag도 라이브러리 시트 양모드 검수에 포함했다.
- 직접 열어본 최종 이미지: 시트 82장, 소스 대조 39장, 삼중 비교 `slide_01.png`부터 `slide_30.png`까지 30장. 파일명과 실제 PNG SHA는 `direct-views-round5.json`에 모두 기록했다. 추가 검수에서 P11 직사각 glass 행을 독립 list--check-rect로 분리했다. 마지막으로 연 화면은 `foundation-panels-dark.png`와 `list--check-rect-replica.png`이며 P11 삼중 비교도 재확인했다.
- `round5-final-audit.json`은 위 결과·이미지 크기·렌더와 컬렉션 SHA·assembly HTML SHA·CSS 스냅샷 동일성·동결 replica 62파일 불변을 함께 확인한다. PDF 및 ZIP 제작은 통합 패키징 도구에서 처리한다.

어려웠던 지점은 source17의 아래로 잘린 원형 허브와 source15의 네 설명·중앙 사진을 분리하는 소유권이었다. 허브는 하나의 viewport 안에 연결 멤버를 모두 두고, source15 외곽은 foundation panel, 각 설명은 독립 card로 만들었다. 정수 그리드 위치와 원본 특유의 유리 질감까지 완전히 같은 결과라고 주장하지 않으며 남은 차이는 review-notes에 기록했다.
