# Round5 report

원본 기반16개 디자인과 foundation panel을 남겼습니다. 신규7개 디자인 폴더로 큰176px표제·140px수치·단순dot목록·중앙본문·14px캡션·67px다음원·516×420이미지비율을 분리했습니다. 요소632건+panel32건은7검사항목 실패0입니다. 원본에 없는 일반47요소를 삭제했고,잔여unexpressible은0입니다. A03하단요약이 replica보다 약70px오른쪽·35px아래인 그리드 차이를 기록했습니다.

Final collection SHA256: `728a85357d9d5adbf23f9b002e76dad2d0a79a98b84be6c618f9afd501f6d552`

Source-derived design folders: 16.

## Origin of each design

- `agenda` ← replica 02
- `card` ← replica 05
- `chart-area` ← replica 06
- `headline` ← replica 04, 05, 06, 07, 08, 09
- `headline--section` ← replica 03
- `image-frame` ← replica 04
- `image-frame--near-square` ← replica 07
- `list` ← replica 04, 06
- `list--bullets` ← replica 03
- `metric--growth` ← replica 06
- `pill--next` ← replica 03
- `prose` ← replica 01, 03, 08
- `prose--caption` ← replica 07
- `prose--center` ← replica 09
- `steps` ← replica 08
- `tag` ← replica 07

## Changes and panels

New independent designs: `headline--section` (03), `list--bullets` (03), `pill--next` (03), `metric--growth` (06), `prose--caption` (07), `image-frame--near-square` (07), `prose--center` (09). Each new folder has two freshly authored fixture states.

Foundation `.panel.ruled` owns the07 process-caption rule and contains tag + caption elements; it has two business fixtures. The oversized03 section word uses the reusable `.head.statement` device so its source600×211 text allocation can retain176px type. Wide/tall/round/device seats are available.

Chart extension: point-owned `.at` silhouette arrows on the06 area chart. All three arrows render above area fills, and their48px source heads scale from width rather than growing with stem height. No page-level arrow layer.

Paragraph CSS was rewritten from native text boxes:08 visual16.9198px,01 opening27.998px/700,01 quiet15.9994px;07 caption14px/21px lives in its own design.03 bullets use16px/400 and24px leading.

## Remaining differences

No structural unexpressible instance remains under the relaxed round5 contract. Image/3D/artwork placeholders remain gray as requested. Integer12×6 grid placement still differs from source absolute positions:03 right-side summary sits about70px right and35px down;04 image is smaller;05 card row starts lower;06 plot and arrow stems extend farther downward;07 caption/illustration placements and08 step allocation follow grid cell boundaries. These are visible geometry differences, recorded explicitly rather than called exact replicas. The source-native component scale is separately measured in `round5-native-audit.json`.

Lucide outlines replace source simple SVGs, so stroke and detail differ slightly. Original source words occur only on validation assembly pages; all component fixtures use new wording.

## Removed generic leaves

`architecture`, `balance`, `bullet`, `callout`, `chart-bar`, `chart-donut`, `chart-line`, `chart-scatter`, `chart-stack`, `chart-waterfall`, `code`, `concentric`, `cycle`, `decision-tree`, `delta`, `flowchart`, `funnel`, `gauge`, `heatmap`, `hierarchy`, `hub`, `journey`, `legend`, `logo-group`, `matrix`, `matrix-nine`, `metric`, `mindmap`, `network`, `person`, `pill`, `positioning`, `pricing`, `pyramid`, `quote`, `radar`, `roadmap`, `sankey`, `slope`, `sparkline`, `swimlane`, `table`, `timeline`, `treemap`, `venn`, `versus`, `waffle`

## Validation and last actually viewed

Actual Chromium light/dark size sheets, native measurements, source comparisons and complete original|replica|assembly triples are included. `round5-viewed.json` records the current image SHA256s actually opened; `size-summary-all.json`, `size-summary-panels.json`, `reassembled-audit.json`, `replica-comparison-audit.json`, `round5-native-audit.json` and `round5-verification.json` record the final checks. Unchanged fixture renders can be reused only after the common tool proves active CSS and fixture equality.


## Foundation fixture final review

CSS and all element fixtures are byte-identical to the accepted version. The generic seat allocation was reduced to keep its square fully inside the page. Afterglow seat no longer contains the unsupported lead. Confluence cover uses source01 kicker/lead/nested title/label/src/portrait/logo order with entirely new Korean copy and the new company name 누리물류. Final light/dark foundation pages were opened at1280×720. Confluence lead/title Range boxes intersect, but independent painted glyph layers have zero overlapping pixels: lead ink ends at229 and title ink starts at241. See foundation-ink-overlap-proof.json.
