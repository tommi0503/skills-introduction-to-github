# Unexpressible

None. Former gaps are represented by explicit design folders, foundation panels, large type tokens, or point-owned chart ornaments.
