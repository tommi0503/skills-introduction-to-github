# Round5 report

원본 기반3개 디자인과 foundation panel을 남겼습니다.03label/value패널과 관련카드를 한 panel 안에115:23:433비율로 복원했습니다. 요소58건+panel32건은7검사항목 실패0입니다. 원본에 없는 일반53요소를 삭제했고,잔여unexpressible은0입니다. panel native 타이포는26px/750과27px/700입니다.

Final collection SHA256: `ecc020cbcfe58d5a76bcb6e38998c6d1dfa7a7acb15eee6667768ccb540f7415`

Source-derived design folders: 3.

## Origin of each design

- `agenda` ← replica 02
- `card` ← replica 03
- `hub` ← replica 04

## Changes and panels

Source03 label/value band is restored as foundation `.panel > .bar + .name`. When a related `.group` of field cards is present, the panel itself owns115:23:433 vertical ratios; no page-dependent sibling condition is used. Two simple and two field-group fixtures cover the two reusable panel structures.

Panel source-native metrics: label26px/750, value27px/700; bar220×98, with the source left10px inset. Label color is the page role in light and ink role in dark so the original white label and both-mode contrast are retained.

The03 field figure and detail copy use n9/n8 roles, matching the source gray hierarchy rather than generic black. No chart extension is used.

## Remaining differences

No structural unexpressible instance remains under the relaxed round5 contract. Artwork remains gray placeholder. Original02 supporting copy was very pale; library typography retains a stronger readable ink role. Integer grid and responsive scaling cause small differences in02 panel positions and04 spoke placement. Lucide icon shapes differ from the source SVG outlines.

## Removed generic leaves

`architecture`, `balance`, `bullet`, `callout`, `chart-area`, `chart-bar`, `chart-donut`, `chart-line`, `chart-scatter`, `chart-stack`, `chart-waterfall`, `code`, `concentric`, `cycle`, `decision-tree`, `delta`, `flowchart`, `funnel`, `gauge`, `headline`, `heatmap`, `hierarchy`, `image-frame`, `journey`, `legend`, `list`, `logo-group`, `matrix`, `matrix-nine`, `metric`, `mindmap`, `network`, `person`, `pill`, `positioning`, `pricing`, `prose`, `pyramid`, `quote`, `radar`, `roadmap`, `sankey`, `slope`, `sparkline`, `steps`, `swimlane`, `table`, `tag`, `timeline`, `treemap`, `venn`, `versus`, `waffle`

## Validation and last actually viewed

Actual Chromium light/dark size sheets, native measurements, source comparisons and complete original|replica|assembly triples are included. `round5-viewed.json` records the current image SHA256s actually opened; `size-summary-all.json`, `size-summary-panels.json`, `reassembled-audit.json`, `replica-comparison-audit.json`, `round5-native-audit.json` and `round5-verification.json` record the final checks. Unchanged fixture renders can be reused only after the common tool proves active CSS and fixture equality.


## Foundation fixture final review

CSS and all element fixtures are byte-identical to the accepted version. The generic seat allocation was reduced to keep its square fully inside the page. Afterglow seat no longer contains the unsupported lead. Confluence cover uses source01 kicker/lead/nested title/label/src/portrait/logo order with entirely new Korean copy and the new company name 누리물류. Final light/dark foundation pages were opened at1280×720. Confluence lead/title Range boxes intersect, but independent painted glyph layers have zero overlapping pixels: lead ink ends at229 and title ink starts at241. See foundation-ink-overlap-proof.json.
