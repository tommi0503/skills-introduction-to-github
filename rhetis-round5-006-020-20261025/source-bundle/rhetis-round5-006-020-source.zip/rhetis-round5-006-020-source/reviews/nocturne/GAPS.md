# GAPS

남은 gap 없음. 이전5인스턴스는 media 카드, 큰 Q&A 표제, foundation 광원 프레임으로 구현했다.
