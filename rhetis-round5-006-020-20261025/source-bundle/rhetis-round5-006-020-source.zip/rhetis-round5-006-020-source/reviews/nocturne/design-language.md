# Nocturne design language

The collection comes from frozen pages19–24. A dark open stage uses restrained corner illumination, centered typography, hairline outlines and a sparse vertical run of dots. Pale full-height media tiles are a second deliberate surface language from page21.

- Circle metric:316px native diameter,3px rule,36px name,60px figure; radius50%. Caption tiles keep square edges and1px separators.
- Capsules:65px native height,2px rule,28px/550 text, approximately30px side inset; text is optically centered with the loaded Pretendard line metrics.
- Media tile:426.7:487 native ratio. Kicker at66/487, mixed-weight46px heading at170/487,18px note67px above the foot; no generic card shadow.
- Display hierarchy:88.3px opening display,56.2px page heading,204px question display and100px Montserrat cover. Components scale these ratios with container units and token-bounded clamps. Small text follows18/24/26/30/32/36/60 roles rather than a shared arbitrary scale.
- Reading panel:25px corners,3px outline, dotted horizontal separators, generous horizontal breathing room. Source artwork furniture remains foundation-owned.
- Accent text and figures use `--a1-7`; question/heading text uses `--ink`; reading surfaces use `--n-1`; media seats use a neutral palette role; rules use `--n-3` through `--n-5`. The opening wordmark blends `--a1-7` into `--ink`. No design CSS owns an original color.
- The stage background mixes palette accent with `--page`; a centered spotlight adds a blurred trapezoid. These are frame/vector grammar, never gap rows.
- Only the actual eight retained designs are delivered. No inferred chart, process or organizational family is included.
