# Nocturne · round 5

- 새 디자인: `card--media` ← p21(사진 바탕의3개 타일, 혼합 굵기2행 표제), `headline--qa` ← p23(30px 초대 문구와204px/600 대형 표제).
- foundation: p19 광원/사다리꼴 빔은 `.slide.spotlight` 배경. p21은 `.edge-media`, p22는 `.message`와 `.seat.panorama`, p23은 `.questions` 가구 배치. 다른 요소를 묶는 추가 패널은 필요하지 않았다.
- 차트 확장 사용: 없음. 이6페이지에는 실제 차트가 없다.
- 삭제: 레플리카에 없는 일반 요소50개. 실제6요소와 새2디자인, 총8개만 남겼다. 삭제 목록은 아래에 적었다.
- 남은 표현 불가 gap:0. 사진/복잡한 그래픽은 기존 회색 placeholder를 유지했다. 이것은 pixel-identical 검증을 뜻하지 않는다.
- 검수:17개 새문구 fixture, 라이트/다크266크기 조합. 글자 영역 초과·겹침·잘림·폰트 실패·본문 숨김·0크기·화면 대비 실패0. 원문6글자 중복2종 검사0. 현재 SHA 및 세부 결과는 `size-summary-all.json`, `contract-round5.json`, `reassembled-audit.json` 참조.
- 주 에이전트가 마지막 수정 후 연 비교: `compare-reassembled/slide_19.png`~`slide_24.png`, `sheets/card--media-replica.png`, `sheets/headline--qa-replica.png`, 새 두 요소의 light/dark 크기 시트. 전체 요소 시트와 최소 칸도 최종 통합 검수했다.

## 시각적으로 남은 차이와 결정

- 색은 CSS에 원본 HEX를 고정하지 않았다. 기본 라이트/다크 시트는 계약 팔레트이고, 대조 페이지에만 `source-palette.json`을 호스트 팔레트로 주입했다. 그래서 원본의 세밀한 광원 색 전이와 동일하지 않다.
- p19 본문, p20 원형 지표와 점선 설명, p22 패널은12×6 할당 안에서 중심을 맞췄다. 일부 수직 간격에 수px 차이가 있다. p23은 확대 토큰204로 원래 표제를 복원하고 foundation 질문 프레임 상단을 조정했다.
- p21의 사진은 고정 replica와 동일한 회색 면이다. p24의 복잡한 유리 그래픽도 고정 replica의 회색 면으로 보존했다.
- 판독 불가 문구를 새로 만든 부분은 없다. 라이브러리 fixture의 물류/운영 문장은 원문과 별개로 새로 작성했다. 조립 검증 페이지만 replica 문구를 사용했다.

## 삭제한 일반 요소

`agenda`, `architecture`, `balance`, `bullet`, `chart-area`, `chart-bar`, `chart-donut`, `chart-line`, `chart-scatter`, `chart-stack`, `chart-waterfall`, `code`, `concentric`, `cycle`, `decision-tree`, `delta`, `flowchart`, `funnel`, `gauge`, `heatmap`, `hierarchy`, `hub`, `image-frame`, `journey`, `legend`, `logo-group`, `matrix`, `matrix-nine`, `metric`, `mindmap`, `network`, `person`, `positioning`, `pricing`, `pyramid`, `quote`, `radar`, `roadmap`, `sankey`, `slope`, `sparkline`, `steps`, `swimlane`, `table`, `tag`, `timeline`, `treemap`, `venn`, `versus`, `waffle`

## Foundation fixture 추가 검수

선택적 cover/seat 예제도 양 모드1280×720로 열어 검수했다. seat의 source에 없는 lead를 제거해 kicker와의 행 상자 교차를 없앴다. cover는 실제 라틴 브랜드 표제를 새 이름 BRIDGEWORKS로 작성하고 source의 두 회색 코너 그래픽과 상단 가구를 포함했다. 요소/기초 CSS는 변경하지 않았다. `foundation-page-audit.json`과 `foundation-review/`에 결과를 남겼다.
