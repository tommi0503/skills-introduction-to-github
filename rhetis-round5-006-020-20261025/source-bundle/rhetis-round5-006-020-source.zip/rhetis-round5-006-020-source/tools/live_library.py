"""Portable, source-powered HTML counterpart to actual-size PNG sheet rows."""
from pathlib import Path
import json,re,html
from size_review import stylesheet,MIN_RE
def make(c,r,lib,display):
 ui='''html,body{margin:0;padding:0}body{font:14px system-ui;background:#e8e8ec;color:#172129}.r5-head{padding:24px;position:sticky;left:0;max-width:1200px}.r5-head h1{font-size:24px}.r5-family{margin:24px}.r5-family>h2{font-size:20px}.r5-row{display:flex;align-items:flex-start;gap:12px;margin:18px 0}.r5-label{flex:0 0 200px;padding:8px;font:14px system-ui;overflow-wrap:anywhere}.r5-case{flex:none}.r5-caption{height:26px;font:13px system-ui;background:#f1f3f4;padding:4px;box-sizing:border-box}.r5-crop{position:relative;overflow:hidden;border:1px solid #c4c9ce;box-sizing:content-box}.r5-offset{position:absolute}.r5-crop .slide{margin:0}.r5-head a{color:#155966}'''
 for mode in ['light','dark']:
  parts=[];rows=0;cells=0
  for leaf in display:
   d=json.loads((r/'sheets'/(leaf+'-audit.json')).read_text());records=[x for x in d['cases']if x['mode']==mode];parts.append('<section class="r5-family" id="'+leaf+'"><h2>'+html.escape(leaf)+'</h2>')
   for fixture in dict.fromkeys(x['fixture']for x in records):
    f=c/'foundation/fixtures'/(fixture+'.html')if leaf=='foundation-panels'else c/'elements'/leaf/'fixtures'/(fixture+'.html');source=MIN_RE.sub('',f.read_text());parts.append('<div class="r5-row"><div class="r5-label">'+html.escape(fixture)+'</div>');rows+=1
    for a in[x for x in records if x['fixture']==fixture]:
     cols,rs=map(int,a['size'].split('x'));m=re.search(r'<[a-z][a-z0-9:-]*\b[^>]*>',source,re.I);tag=m[0];st=re.search(r'''style\s*=\s*(['"])(.*?)\1''',tag,re.S);style=re.sub(r'grid-(?:column|row)\s*:[^;]+;?','',st[2]if st else'');style+=f';grid-column:1 / span {cols};grid-row:1 / span {rs}';newstyle='style="'+html.escape(style,quote=True)+'"';tag=tag[:st.start()]+newstyle+tag[st.end():]if st else tag[:-1]+' '+newstyle+'>';content=source[:m.start()]+tag+source[m.end():];z=a['rect'];label=a['size']+(' · MIN'if a['minimum']else'');body='<section class="slide'+(' dark'if mode=='dark'else'')+'"><div class="page"><div class="body">'+content+'</div></div></section>'
     parts.append('<div class="r5-case"><div class="r5-caption">'+label+'</div><div class="r5-crop" style="width:'+str(z['width'])+'px;height:'+str(z['height'])+'px"><div class="r5-offset" style="left:-'+str(z['x'])+'px;top:-'+str(z['y'])+'px">'+body+'</div></div></div>');cells+=1
    parts.append('</div>')
   parts.append('</section>')
  f=lib/(mode+'.html')
  if f.exists():f.rename(lib/(mode+'-png-gallery.html'))
  f.write_text('<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+c.name+' '+mode+' live library</title><link rel="stylesheet" href="../assets/fonts/fonts.css"><style>'+stylesheet(c,mode)+'\n'+ui+'</style><script defer src="../assets/icons-runtime.js"></script></head><body><header class="r5-head"><h1>'+c.name+' · '+mode+' · 크기별 라이브러리</h1><p>각 행은 fixture 하나입니다. 최소 칸과12×6까지 같은 컬렉션 소스를 렌더합니다. 가로로 스크롤하여 확인하세요.</p><a href="'+mode+'-png-gallery.html">요소별 PNG 시트</a> · <a href="foundation-'+mode+'.html">Foundation 예제</a> · <a href="library-'+mode+'.pdf">전체 PDF</a></header>'+''.join(parts)+'</body></html>')
  print(c.name,mode,'live rows',rows,'cells',cells,flush=True)
