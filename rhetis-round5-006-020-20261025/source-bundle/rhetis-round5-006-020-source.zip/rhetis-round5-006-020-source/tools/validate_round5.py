"""Round5 source review; no obsolete 56-leaf/model-fixture completeness gate."""
from pathlib import Path
from html.parser import HTMLParser
import argparse,json,re,sys,hashlib
sys.path.insert(0,'/workspace/work/tools')
from css_syntax_audit import headers
B=Path('/workspace/work/round5-20261025');REF=Path('/workspace/work/reference')
STEPS=set(range(8,33,2))|set(range(36,257,4))
class Markup(HTMLParser):
 def __init__(self):super().__init__();self.depth=0;self.top=[];self.tags=[]
 def handle_starttag(self,t,a):
  a=dict(a);self.tags.append((t,a))
  if self.depth==0:self.top.append((t,a))
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.depth+=1
 def handle_startendtag(self,t,a):self.tags.append((t,dict(a)))
 def handle_endtag(self,t):self.depth=max(0,self.depth-1)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def split_args(v):
 out=[];depth=0;start=0
 for i,ch in enumerate(v):
  if ch=='(':depth+=1
  elif ch==')':depth-=1
  elif ch==',' and depth==0:out.append(v[start:i].strip());start=i+1
 return out+[v[start:].strip()]
def validate(name):
 c=B/name/'collection'/name;errors=[];warn=[];counts={'elements':0,'fixtures':0,'panelFixtures':0};elements={p.name for p in (c/'elements').iterdir() if p.is_dir()};ref=REF/'samples/annual/elements'
 def error(p,msg):errors.append({'file':str(p.relative_to(c)),'message':msg})
 def check_fixture(p,key):_fixture_impl(c,elements,p,key,error)
 for p in c.rglob('*'):
  if p.is_file() and p.suffix not in {'.css','.json','.md','.html'}:error(p,'Forbidden collection file type')
  if p.suffix=='.json':
   try:json.loads(p.read_text())
   except Exception as ex:error(p,'Invalid JSON: '+str(ex))
 for f in ['kit/kit.json','kit/css/tokens.css','kit/description.md','foundation/foundation.css','foundation/foundation.json','foundation/description.md']:
  if not (c/f).exists():error(c/f,'Missing required source')
 for leaf in sorted(elements):
  d=c/'elements'/leaf;base=leaf.split('--',1)[0];key=name+'-'+leaf;counts['elements']+=1
  if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*(?:--[a-z0-9]+(?:-[a-z0-9]+)*)?',leaf):error(d,'Invalid leaf/design name')
  if not(ref/base).exists():error(d,'Unknown base contract');continue
  for f in ['element.css','element.json','description.md']:
   if not(d/f).exists():error(d/f,'Missing element source')
  meta=json.loads((d/'element.json').read_text());expected=json.loads((ref/base/'element.json').read_text())
  if meta.get('schema')!='rhetis.design-library-element-source/1' or meta.get('contract')!=expected['contract']:error(d/'element.json','Schema/contract mismatch')
  if any(not x.startswith('--'+name+'-') for x in meta.get('tokenDefaults',{})):error(d/'element.json','Unprefixed component token')
  if len((d/'description.md').read_text().strip())<35:error(d/'description.md','Description is not sufficiently specific')
  fixtures=sorted((d/'fixtures').glob('*.html'));counts['fixtures']+=len(fixtures)
  if len(fixtures)<2:error(d/'fixtures','At least two new-copy fixtures required')
  for p in fixtures:check_fixture(p,key)
  s=(d/'element.css').read_text();bare=re.sub(r'/\*.*?\*/','',s,flags=re.S)
  if not s.lstrip().startswith('/*'):error(d/'element.css','Missing replica provenance comment')
  if not re.search(r'container-type\s*:\s*size|container\s*:[^;{}]*/\s*size',bare):error(d/'element.css','Missing size container')
  if not re.search(r'cq[wh]',bare):warn.append({'file':str((d/'element.css').relative_to(c)),'message':'No explicit cqw/cqh; inspect responsive sizing'})
  for h in headers(s):
   if h.startswith('@'):continue
   for sel in split_args(h):
    if not re.match(r'\.[a-z][a-z0-9-]*\[data-el=["\']'+re.escape(key)+r'["\']\]',sel):error(d/'element.css','Selector lacks own root/key: '+sel[:180])
  old=Path('/workspace/work/deliverables')/name/'collection'/name/'elements'/leaf/'element.css'
  if old.exists() and sha(old)==sha(d/'element.css'):error(d/'element.css','Unchanged original collection CSS')
 for p in c.rglob('*.css'):
  s=re.sub(r'/\*.*?\*/','',p.read_text(),flags=re.S)
  if re.search(r'@(import|font-face|keyframes)\b|url\s*\(',s,re.I):error(p,'External resource or unsupported animation')
  for v in re.findall(r'(?<![-\w])font-size\s*:\s*([^;}]+)',s):
   v=v.strip();valid=bool(re.fullmatch(r'var\(--type-\d+\)',v))
   if v.startswith('clamp(') and v.endswith(')'):
    args=split_args(v[6:-1]);valid=len(args)==3 and bool(re.fullmatch(r'var\(--type-\d+\)',args[0])) and bool(re.fullmatch(r'var\(--type-\d+\)',args[2])) and not bool(re.search(r'\d(?:px|vw|vh)',v))
   if not valid or any(int(x)not in STEPS for x in re.findall(r'--type-(\d+)',v)):error(p,'Font size outside token/clamp contract: '+v)
  if p!=c/'kit/css/tokens.css':
   if re.search(r'#[0-9a-fA-F]{3,8}\b|\b(?:rgb|rgba|hsl|hsla|oklch|oklab)\s*\(',s):error(p,'Literal color outside palette tokens')
   if re.search(r'(?<![-\w])(?:color|background(?:-color)?|fill|stroke)\s*:\s*(?:white|black|gray|grey|red|blue|yellow|green)\b',s):error(p,'Named color outside palette tokens')
 for p in sorted((c/'foundation/fixtures').glob('panel-*.html')):counts['panelFixtures']+=1;check_fixture(p,None)
 def finish():
  result={'collection':name,'counts':counts,'errors':errors,'warnings':warn,'policy':'Round5 partial collections and multiple designs allowed; model/state fixtures optional; typography8–256; source-derived responsive designs.'};(B/name/'review/contract-round5.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(name,counts,'errors',len(errors),'warnings',len(warn));return result
 return finish()

def _fixture_impl(c,elements,p,key,error):
 s=p.read_text();m=re.match(r'<!--\s*min:\s*([^>]+)-->',s)
 if not m:error(p,'Missing first-line minimum')
 elif not all(1<=int(a)<=12 and 1<=int(b)<=6 for a,b in re.findall(r'(\d+)x(\d+)',m[1])):error(p,'Invalid minimum')
 x=Markup();x.feed(s)
 if len(x.top)!=1:error(p,'Expected one fixture root')
 if key and not any(a.get('data-el')==key for _,a in x.tags):error(p,'Fixture lacks own data-el')
 for t,a in x.tags:
  if 'data-el' in a:
   v=a['data-el'];prefix=c.name+'-'
   if not v.startswith(prefix) or v[len(prefix):]not in elements:error(p,'Unresolved dependency '+v)
  if t in {'img','script','iframe'}:error(p,'Unsupported fixture media/script')
  if 'data-icon'in a and not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*',a['data-icon']):error(p,'Invalid Lucide name')

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('names',nargs='+');x=a.parse_args();results=[validate(n)for n in x.names];raise SystemExit(any(r['errors']for r in results))
