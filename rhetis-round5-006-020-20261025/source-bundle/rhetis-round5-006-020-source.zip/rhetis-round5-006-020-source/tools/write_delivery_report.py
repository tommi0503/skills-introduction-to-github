"""Build the Korean delivery index from final folders and source mappings."""
from pathlib import Path
import json,re
from package_round5 import B,OUT,NAMES,COUNTS
DETAIL={
'nocturne':('중앙 광원·빔은 foundation 배경으로, 사진 위 타일과204px 질문 표제는 독립 디자인으로 복원했다.','추가 패널·차트 없음.'),
'inflexion':('시장 산형도·세 종류 표제·배너·원형 차트·제어 흐름·9개 사건 타임라인 등을 분리했다.','차트 면 패널·카드 틀,3조각 파이/도넛,3분할 축,점/선/면 데이터를 사용했다. 원형 비율·축·균일30%면·본문 관통 점선을 수정했다.'),
'diecut':('제품 가로 카드와 세로 카탈로그, 아치·후기·인증 카드, 기울어진 ROI 타원,7단계 순환 등을 분리했다.','제품·시장·KPI·ROI·후기·인증·전체 캔버스 패널과8막대+선 콤보를 사용했다. 사진12px 모서리를 복원했다.'),
'afterglow':('176px 표제·140px 수치·작은 점 목록·14px 캡션·중앙 본문·사진 비율·다음 버튼을 분리했다.','Process 설명의 ruled 패널과 영역 차트 점이 소유하는3개 화살표를 사용했다.'),
'dockside':('폴더·미디어 행·화면 흐름·확대 사진·아이디어 허브·결과·대화 등 실제 디자인을 분리했다.','6종 패널을 사용했다.04 캡슐 체크 행과11 직사각 체크 행을 독립시켰고, 폴더 사진 창 선택자·아이콘 자리·대비를 수정했다.'),
'confluence':('실제3종 요소를 유지하고 프로젝트의 label/value 띠와 카드3개를 foundation 패널로 묶었다.','프로젝트 띠·필드 패널의115:23:433 비율을 복원했다. 새 차트 확장 없음.')}
def main():
 delivery=json.loads((OUT/'delivery-validation.json').read_text());by={x['collection']:x for x in delivery['collections']};origins=['# Round5 새 디자인 출처\n\n레플리카의 디자인 인스턴스를 먼저 식별한 뒤 독립 요소로 매핑했다. 반복 인스턴스는 같은 디자인으로 묶었다.\n\n| 컬렉션 | 새 디자인 폴더 | 레플리카 페이지 |\n|---|---|---|'];summary=[];records=[]
 for n in NAMES:
  c=B/n/'collection'/n;mp=json.loads((B/n/'review/map.json').read_text());actual={p.name for p in(c/'elements').iterdir()if p.is_dir()};old={p.name for p in(Path('/workspace/work/rebuild-20261024')/n/'collection'/n/'elements').iterdir()if p.is_dir()};new=sorted(actual-old);deleted=sorted(old-actual);gaps=[x for x in mp['instances']if x['use']=='unexpressible'];newmap=[]
  for leaf in new:
   pages=sorted({str(x['page']).zfill(2)for x in mp['instances']if x.get('leaf')==leaf});label=', '.join(pages)or'개별 report/map 참조';origins.append('| '+n+' | `elements/'+leaf+'/` | '+label+' |');newmap.append({'folder':'elements/'+leaf,'replicaPages':pages})
  z=by[n];r={'collection':n,'elements':len(actual),'newDesigns':newmap,'deletedGeneric':deleted,'remainingGaps':gaps,'elementCases':z['renderGate']['elementCases'],'panelCases':z['renderGate']['panelCases'],'sourceSHA256':z['renderGate']['sourceSHA256']};records.append(r)
  summary.append('| '+n+' | '+str(len(actual))+' | '+str(len(new))+' | '+str(len(deleted))+' | '+str(len(gaps))+' | '+str(r['elementCases']+r['panelCases'])+' | ['+str(COUNTS[n])+'p 보고](reviews/'+n+'/round5-report.md) |')
 report=['# Round5 검수·변경 보고\n\n기존 replica191파일은 바꾸지 않았다. 실제 소스의 디자인만 남겼으며, 추가 디자인과 패널로 이전84개 gap 인스턴스를 재분류했다. **남은 표현 불가 gap은0이며, 원본과 남은 배치·줄바꿈·질감 차이는 각 보고서에 별도로 적었다. 픽셀100% 동일을 주장하는 결과가 아니다.**\n\n| 컬렉션 | 요소 | 새 디자인 | 일반 삭제 | gap | 요소·패널 조건 | 상세 |\n|---|---:|---:|---:|---:|---:|---|']+summary
 for n in NAMES:
  text,extra=DETAIL[n];report.append('\n**'+n+'** — '+text+' '+extra+' 새 폴더와 페이지 대응은 [전체 출처표](element-origins.md), 패널·차트·삭제 목록·마지막 실제 열람 파일은 [개별 보고](reviews/'+n+'/round5-report.md)와 해당 JSON receipt에 있다.')
 report.append('\n요소와 패널은 라이트·다크에서 fixture별 최소 칸부터12×6까지 실제 Chromium으로 렌더했다. 글자 영역 초과·클리핑·폰트 실패·필수 글자 숨김·0크기·실측 대비 문제는 남지 않았다. Diecut의 SUITE 행 상자 접촉6조건은 교차 영역의 실제 글자 픽셀0으로 확인했으며, Confluence 표지의 행 상자 접촉도 독립 글자층의 실제 교집합0으로 확인했다. 기본 foundation 예제도 양 모드1280×720로 열어 보았다.\n\n사진·3D·화면은 요청대로 회색 자리로 두었다. fixture 문구는 새로 작성했고, 검증 조립본만 replica 문구를 사용했다. 기존 replica 제작 때의 판독 불가·보완 문구 기록은 각 검수 ZIP의 `replica-review-notes.md`에 함께 보존했다.\n\nGit 명령 금지 지시에 따라 이번 라운드는 로컬 제출물로 제공한다. GitHub에 새 commit·push를 하지 않았다. 최종 압축 파일은 로컬 HTTP로 다시 내려받아 SHA256·CRC를 검사하며, 결과는 `final-verification.json`에 기록한다.\n')
 (OUT/'REPORT.md').write_text('\n'.join(report));(OUT/'element-origins.md').write_text('\n'.join(origins)+'\n');(OUT/'round5-summary.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
 index=['# 소스·다운로드\n\n[검수 미리보기](preview.html) · [변경 보고](REPORT.md) · [새 디자인 출처](element-origins.md)\n\n| 컬렉션 | 소스 ZIP | 검수 ZIP | 키트 | Foundation |\n|---|---|---|---|---|']
 for n in NAMES:index.append('| '+n+' | ['+n+'.zip]('+n+'.zip) | [검수 ZIP]('+n+'-review.zip) | [kit.json](collections/'+n+'/kit/kit.json) | [CSS](collections/'+n+'/foundation/foundation.css) |')
 (OUT/'SOURCE-INDEX.md').write_text('\n'.join(index)+'\n')
 (OUT/'README.md').write_text('# Rhetis Round5 ·6개 컬렉션\n\n[미리보기](preview.html)에서 컬렉션과 요소를 선택하면 크기별 시트·replica 부분 대조·페이지3자 비교를 볼 수 있다. [소스와 ZIP](SOURCE-INDEX.md), [변경 보고](REPORT.md), [검증 결과](final-verification.json)를 함께 제공한다.\n\n컬렉션 ZIP은 최상위 컬렉션 폴더 하나와 `.css/.json/.md/.html`만 포함한다. 검수 ZIP에는 고정 replica·소스와1280×720 PNG·PDF, 원본/조립2자 비교, 원본/replica/조립3자 비교, 요소별 양 모드 PNG·소스로 동작하는 HTML 시트·전체 PDF가 있다. 기본 foundation 예제는 library의 Foundation 링크에서 본다.\n\n색은 호스트 팔레트가 공급한다. 기본 시트는 계약 팔레트, 원본 대조는 별도 source-palette를 사용한다. Round5의8–256px 타입 범위를 검수 도구에 반영했으며 목록은 `tools/type-steps-round5.json`에 있다. 원본 레퍼런스의 공식 반입 서비스는 제공되지 않아, 포함된 소스·브라우저·압축 검수로 확인했다.\n\n이전 작업은 그대로 보존했다. 이번 라운드에는 Git 명령과 외부 게시를 하지 않았다.\n')
 print('Korean report/source index ready:',sum(x['elements']for x in records),'designs',sum(len(x['newDesigns'])for x in records),'new',sum(len(x['deletedGeneric'])for x in records),'deleted')
if __name__=='__main__':main()
