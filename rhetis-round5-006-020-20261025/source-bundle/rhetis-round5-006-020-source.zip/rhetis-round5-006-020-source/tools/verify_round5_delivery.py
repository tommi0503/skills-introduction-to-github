"""Open the final viewer/library HTML and re-download every archive over local HTTP."""
from pathlib import Path
import hashlib,json,sys,zipfile,urllib.request,tempfile
import fitz
from playwright.sync_api import sync_playwright
from size_review import browser,serve_url
OUT=Path('/workspace/work/round5-delivery-20261025')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 delivery=json.loads((OUT/'delivery-validation.json').read_text());assert len(delivery['collections'])==6 and len(delivery['zips'])==12
 result={'browser':[],'pdfs':[],'archiveRedownloads':[],'remotePublication':False,'reason':'User Round5 forbids Git commands; these are local delivery/HTTP verification results.'}
 with sync_playwright()as pw:
  b=browser(pw);p=b.new_page(viewport={'width':1440,'height':1000});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.goto(serve_url(OUT/'preview.html'),wait_until='load')
  for c in delivery['collections']:
   n=c['collection'];p.select_option('#collection',n);p.wait_for_function('()=>document.querySelector("#artifact").complete&&document.querySelector("#artifact").naturalWidth>0')
   count=p.locator('#leaf option').count();assert count==c['elements'],(n,'viewer count',count,c['elements'])
   p.locator('[data-mode="dark"]').click();p.wait_for_function('()=>document.querySelector("#artifact").complete&&document.querySelector("#artifact").naturalWidth>0');p.locator('[data-tab="pages"]').click();p.wait_for_function('()=>document.querySelector("#artifact").complete&&document.querySelector("#artifact").naturalWidth===3840')
   assert p.locator('#page option').count()==c['pages']
   result['browser'].append({'collection':n,'viewerElementOptions':count,'pageOptions':p.locator('#page option').count(),'threewayImageLoaded':True});p.locator('[data-tab="sizes"]').click()
  assert not errors,errors
  p.select_option('#collection','nocturne');p.select_option('#leaf','card--media');p.locator('[data-tab="replica"]').click();p.wait_for_function('()=>document.querySelector("#artifact").complete&&document.querySelector("#artifact").naturalWidth>0');p.screenshot(path=str(OUT/'preview.png'))
  for c in delivery['collections']:
   for mode in ['light','dark']:
    f=OUT/'reviews'/c['collection']/'library'/(mode+'.html');p.goto(serve_url(f),wait_until='load');p.evaluate('document.fonts.ready');roots=p.locator('.r5-crop [data-el]').count();assert roots>0;assert not p.locator('[data-icon-error]').count();font_failures=p.evaluate('()=>[...document.fonts].filter(f=>f.status==="error").length');assert font_failures==0,(c['collection'],mode,'font failures',font_failures);result['browser'].append({'collection':c['collection'],'library':mode,'liveElementInstances':roots,'fontFailures':font_failures})
  b.close()
 for c in delivery['collections']:
  root=OUT/'reviews'/c['collection']
  for rel,expected in [('replica/replica.pdf',c['pages']),('reassembled/reassembled.pdf',c['pages']),('library/library-light.pdf',c['libraryPDFPages']),('library/library-dark.pdf',c['libraryPDFPages'])]:
   with fitz.open(root/rel)as d:assert len(d)==expected;result['pdfs'].append({'file':str((root/rel).relative_to(OUT)),'pages':len(d)})
 with tempfile.TemporaryDirectory(prefix='round5-redownload-',dir='/tmp')as temp:
  for z in delivery['zips']:
   original=OUT/z['file'];downloaded=Path(temp)/z['file'];urllib.request.urlretrieve(serve_url(original),downloaded);assert sha(downloaded)==z['sha256']==sha(original)
   with zipfile.ZipFile(downloaded)as a:assert a.testzip()is None;count=len(a.namelist())
   result['archiveRedownloads'].append({'file':z['file'],'sha256':z['sha256'],'localHTTP':'pass','zipCRC':'pass','entries':count})
 result['passed']=True;(OUT/'final-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('Browser/library/PDF verification and12 local HTTP archive re-downloads passed.',flush=True)
if __name__=='__main__':run()
