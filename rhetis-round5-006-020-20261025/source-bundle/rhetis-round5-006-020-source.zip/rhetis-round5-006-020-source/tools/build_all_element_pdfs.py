"""Create bookmarked all-collection review PDFs from the final element sheets."""
from pathlib import Path
import hashlib,json,shutil
import fitz

ROOT=Path('/workspace/work/round5-delivery-20261025')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def main():
    delivery=json.loads((ROOT/'delivery-validation.json').read_text())
    out=ROOT/'element-review-pdfs';out.mkdir(exist_ok=True)
    results=[]
    for mode in ['light','dark']:
        combined=fitz.open();toc=[]
        for c in delivery['collections']:
            n=c['collection'];source=ROOT/'reviews'/n/'library'/f'library-{mode}.pdf'
            target=out/f'{n}-{mode}.pdf'
            if target.exists():target.unlink()
            target.hardlink_to(source)
            leaves=sorted(x.name for x in(ROOT/'collections'/n/'elements').iterdir()if x.is_dir())
            panels=(ROOT/'reviews'/n/'library/foundation-panels'/f'{mode}.png').exists()
            basic=sorted((ROOT/'reviews'/n/'foundation-review').glob(f'*-{mode}.png'))
            labels=leaves+(['foundation-panels']if panels else[])+[x.stem for x in basic]
            with fitz.open(source)as pdf:
                assert len(pdf)==len(labels)==c['libraryPDFPages']
                start=len(combined);combined.insert_pdf(pdf)
                toc.append([1,n,start+1])
                toc.extend([2,label,start+i+1]for i,label in enumerate(labels))
            results.append({'file':str(target.relative_to(ROOT)),'collection':n,'mode':mode,'pages':len(labels),'elements':len(leaves),'sha256':sha(target),'bytes':target.stat().st_size})
        combined.set_toc(toc)
        combined.set_metadata({'title':f'Rhetis Round5 – all element review sheets – {mode}','subject':'135 source-based responsive elements; fixtures by size; includes panels and foundation examples','author':'Rhetis'})
        target=out/f'all-elements-{mode}.pdf';combined.save(target,garbage=3,deflate=True);count=len(combined);combined.close()
        with fitz.open(target)as check:
            assert len(check)==155
            assert len([x for x in check.get_toc()if x[0]==2])==155
            for i in [0,49,100,len(check)-1]:
                pix=check[i].get_pixmap(matrix=fitz.Matrix(min(1,1800/check[i].rect.width),min(1,1800/check[i].rect.width)),alpha=False)
                pix.save(out/f'proof-{mode}-{i+1:03}.png')
        results.append({'file':str(target.relative_to(ROOT)),'collection':'all','mode':mode,'pages':count,'elements':135,'sha256':sha(target),'bytes':target.stat().st_size})
    (out/'verification.json').write_text(json.dumps({'passed':True,'uniqueElements':135,'collections':6,'sizes':'declared minimum to12×6, every fixture','pdfs':results},ensure_ascii=False,indent=2))
    rows=['# 전체 요소 검수 PDF','', '총135개 요소를 모두 포함한다. 각 요소 페이지는 fixture별 한 행, 크기별 한 열이며 선언된 최소 칸부터12×6까지 비교한다. 패널과 기본 foundation 예제도 포함해 모드마다155페이지다. 확대하여 작은 칸의 문구와 정렬을 확인할 수 있다.','', '[전체 라이트 ·155p](all-elements-light.pdf) · [전체 다크 ·155p](all-elements-dark.pdf)','', '| 컬렉션 | 라이트 | 다크 |','|---|---|---|']
    for c in delivery['collections']:
        n=c['collection'];rows.append(f'|{n} ·{c["elements"]}요소|[{c["libraryPDFPages"]}p]({n}-light.pdf)|[{c["libraryPDFPages"]}p]({n}-dark.pdf)|')
    rows+=['','원래 PNG 시트와 실제 HTML 시트는 각 컬렉션의 `reviews/<collection>/library/`에 있다.']
    (out/'README.md').write_text('\n'.join(rows)+'\n')
    print('14 review PDFs ready:135 elements,155 pages/mode',flush=True)
if __name__=='__main__':main()
