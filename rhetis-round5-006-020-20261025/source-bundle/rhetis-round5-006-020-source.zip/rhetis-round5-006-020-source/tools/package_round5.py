"""Local Round5 delivery, preserving replicas and previous deliveries. No Git operations."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile,sys,re,html
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from size_review import source_hash
B=Path('/workspace/work/round5-20261025');OUT=Path('/workspace/work/round5-delivery-20261025');OLD=Path('/workspace/work/deliverables');REF=Path('/workspace/work/reference')
NAMES=['nocturne','inflexion','diecut','afterglow','dockside','confluence'];COUNTS=dict(nocturne=6,inflexion=20,diecut=19,afterglow=9,dockside=30,confluence=4)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
def freeze():
 data=json.loads((B/'replica-freeze.json').read_text());rows=[]
 for n,items in data.items():
  for x in items:
   p=OLD/n/'review'/x['file'];rows.append({'collection':n,'file':x['file'],'unchanged':p.exists()and sha(p)==x['sha256']})
 result={'files':len(rows),'unchanged':all(x['unchanged']for x in rows),'checks':rows};assert result['unchanged'],'Frozen replica changed'
 (B/'replica-freeze-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));return result
def gate(n):
 c=B/n/'collection'/n;r=B/n/'review';current=source_hash(c);summary=json.loads((r/'size-summary-all.json').read_text());assert summary['sourceSHA256']==current and summary['sourceUnchanged'],(n,'stale summary')
 for key in ['outsideCases','clipCases','fontFailureCases','hiddenCases','zeroCases','pixelFailureCases']:assert summary[key]==0,(n,key,summary[key])
 ink=None
 if summary['overlapCases']:
  ink=json.loads((r/'ink-overlap-proof.json').read_text());assert ink['sourceSHA256']==current and ink['allInkClear'],(n,'unproven glyph intersection')
  assert len({(x['fixture'],x['mode'],x['size'])for x in ink['cases']})==summary['overlapCases']
  assert all(x['glyphPixelsInIntersection']==0 for x in ink['cases'])
 assert not json.loads((r/'contract-round5.json').read_text())['errors'],(n,'source validation')
 for fn in ['copy-audit.json','copy-block-audit.json']:assert not json.loads((r/fn).read_text())['collisions'],(n,fn)
 leaves=sorted(p.name for p in(c/'elements').iterdir()if p.is_dir());audit_leaves=leaves+(['foundation-panels']if list((c/'foundation/fixtures').glob('panel-*.html'))else[]);casecount=0;panelcases=0
 for leaf in audit_leaves:
  p=r/'sheets'/(leaf+'-audit.json');d=json.loads(p.read_text())
  if d['sourceSHA256']!=current:
   proof=json.loads((r/'render-reuse'/(leaf+'.json')).read_text());assert proof['currentSourceSHA256']==current,(n,leaf,'stale source proof')
  for v in d['cases']:
   fixture=c/'foundation/fixtures'/(v['fixture']+'.html')if leaf=='foundation-panels'else c/'elements'/leaf/'fixtures'/(v['fixture']+'.html')
   assert sha(fixture)==v['fixtureSHA256'],(n,leaf,'stale fixture')
   for key in ['outsideText','clipped','fontFailures','hiddenEssential','zeroRoots','scriptErrors']:assert not v.get(key),(n,leaf,key)
   if v['textOverlaps']:
    proof=[x for x in(ink or{}).get('cases',[])if(x['fixture'],x['mode'],x['size'])==(v['fixture'],v['mode'],v['size'])]
    assert len(proof)==len(v['textOverlaps']) and all(x['glyphPixelsInIntersection']==0 for x in proof),(n,leaf,'unproven text overlap')
   assert v.get('pixelContrast')is not None and not v['pixelContrast']['failures'],(n,leaf,'contrast')
   if leaf=='foundation-panels':panelcases+=1
   else:casecount+=1
  for mode in ['light','dark']:assert(r/'sheets'/(leaf+'-'+mode+'.png')).exists()
 assert casecount==summary['cases'],(n,'case counts',casecount,summary['cases'])
 audit=json.loads((r/'reassembled-audit.json').read_text());assert audit['sourceSHA256']==current,(n,'stale assembly')
 assert len(audit['pages'])==COUNTS[n]
 for p in audit['pages']:
  assert sha(r/'reassembled'/p['file'])==p['htmlSHA256']
  for k in ['clipped','failedFonts','zeroElementRoots','iconErrors']:assert not p[k],(n,p['file'],k)
  assert p['slide']['width']==1280 and p['slide']['height']==720,(n,p['file'],'canvas dimensions')
  assert p['document']=={'width':1280,'height':720},(n,p['file'],'document dimensions')
 return {'sourceSHA256':current,'elementCases':casecount,'panelCases':panelcases,'sourceUnchanged':True,'rangeBoxContactsWithoutGlyphPixels':summary['overlapCases'],'allAutomatedChecks':'pass'}
def pdf(images,out):
 cv=canvas.Canvas(str(out),pageCompression=1)
 for p in images:
  with Image.open(p)as im:
   w,h=im.size;scale=min(.75,14000/max(w,h));pw,ph=w*scale,h*scale
   cv.setPageSize((pw,ph));cv.drawImage(str(p),0,0,width=pw,height=ph);cv.showPage()
 cv.save()
def zipdir(source,out,top):
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in sorted(source.rglob('*')):
   if p.is_file():z.write(p,str(Path(top)/p.relative_to(source)))
 with zipfile.ZipFile(out)as z:
  assert z.testzip()is None
  assert{x.split('/')[0]for x in z.namelist()}=={top}
  if not out.name.endswith('-review.zip'):assert all(Path(x).suffix in {'.css','.json','.md','.html'}for x in z.namelist())
 return {'file':out.name,'bytes':out.stat().st_size,'sha256':sha(out),'zipIntegrity':'pass'}
def stage(n):
 current=gate(n);c=B/n/'collection'/n;r=B/n/'review';tc=OUT/'collections'/n;tr=OUT/'reviews'/n
 for p in [tc,tr]:
  if p.exists():shutil.rmtree(p)
 shutil.copytree(c,tc);tr.mkdir(parents=True)
 for p in r.iterdir():
  if p.is_file()and p.suffix in {'.md','.json'}:copy(p,tr/p.name)
 for folder in ['sheets','probes','render-reuse','reassembled','foundation-review']:
  if(r/folder).exists():shutil.copytree(r/folder,tr/folder,ignore=shutil.ignore_patterns('__pycache__'))
 shutil.copytree(OLD/n/'review/replica',tr/'replica')
 shutil.copytree(OLD/n/'review/compare-replica',tr/'compare-replica')
 shutil.copytree(r/'compare-reassembled',tr/'compare-threeway')
 (tr/'compare-reassembled').mkdir()
 for p in(tr/'compare-threeway').glob('*.png'):
  with Image.open(p)as im:
   assert im.size==(3840,720);pair=Image.new('RGB',(2560,720));pair.paste(im.crop((0,0,1280,720)));pair.paste(im.crop((2560,0,3840,720)),(1280,0));pair.save(tr/'compare-reassembled'/p.name,compress_level=3)
 shutil.copytree(REF/'fonts',tr/'assets/fonts');shutil.copytree(c,tr/'assets/collection')
 for p in(r/'assets').glob('*.js'):copy(p,tr/'assets'/p.name)
 copy(Path('/workspace/work/tools/icons-runtime.js'),tr/'assets/icons-runtime.js');copy(Path('/workspace/work/tools/LUCIDE-LICENSE.txt'),tr/'assets/LUCIDE-LICENSE.txt')
 for p in(OLD/n/'review/assets').glob('*.css'):copy(p,tr/'assets'/p.name)
 if not(tr/'design-language.md').exists():copy(OLD/n/'review/design-language.md',tr/'design-language.md')
 copy(B/'replica-freeze-validation.json',tr/'replica-freeze-validation.json')
 for original,renamed in [('review-notes.md','replica-review-notes.md'),('image-inventory.md','image-inventory.md')]:
  p=OLD/n/'review'/original
  if p.exists():copy(p,tr/renamed)
 leaves=sorted(p.name for p in(c/'elements').iterdir()if p.is_dir());display=leaves+(['foundation-panels']if(tr/'sheets/foundation-panels-light.png').exists()else[])
 lib=tr/'library';lib.mkdir()
 for mode in ['light','dark']:
  sections=[];pngs=[]
  for leaf in display:
   p=tr/'sheets'/(leaf+'-'+mode+'.png');q=lib/leaf/(mode+'.png');copy(p,q);pngs.append(q)
   sections.append('<section id="'+leaf+'"><h2>'+html.escape(leaf)+'</h2><div><img loading="lazy" src="'+leaf+'/'+mode+'.png" alt="'+html.escape(leaf)+' '+mode+' fixture sizes"></div></section>')
  (lib/(mode+'.html')).write_text('<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+n+' '+mode+' 크기별 시트</title><style>body{margin:24px;font:16px system-ui;background:#edf0f2;color:#172129}h1{font-size:24px}h2{font-size:18px}section{margin:32px 0}section div{overflow:auto;border:1px solid #bac4c9;background:#fff}img{display:block;max-width:none}a{color:#155966}</style><h1>'+n+' · '+mode+' · fixture별 크기 시트</h1><p>각 행은 fixture 하나입니다. 선언한 최소 칸부터 12×6까지 실제 브라우저에서 렌더했습니다. 가로로 스크롤하여 원래 크기로 확인할 수 있습니다.</p><nav>'+' · '.join('<a href="#'+x+'">'+x+'</a>'for x in display)+'</nav>'+''.join(sections)+'</html>')
  foundation_pages=sorted((tr/'foundation-review').glob('*-'+mode+'.png'))
  pdf(pngs+foundation_pages,lib/('library-'+mode+'.pdf'))
  examples=[]
  for p in foundation_pages:
   examples.append('<section><h2>'+html.escape(p.stem)+'</h2><iframe title="'+html.escape(p.stem)+'" src="../foundation-review/'+p.with_suffix('.html').name+'" width="1280" height="720"></iframe><p><a href="../foundation-review/'+p.name+'">PNG</a></p></section>')
  (lib/('foundation-'+mode+'.html')).write_text('<!doctype html><html lang="ko"><meta charset="utf-8"><title>'+n+' foundation '+mode+'</title><style>body{margin:24px;font:14px system-ui;background:#e8e8ec}iframe{border:0}h2{font-size:18px}</style><h1>'+n+' foundation · '+mode+'</h1>'+''.join(examples)+'</html>')
 from live_library import make
 make(c,r,lib,display)
 pdf(sorted((tr/'reassembled').glob('*.png')),tr/'reassembled/reassembled.pdf')
 sizes=[]
 for p in tr.rglob('*.png'):
  with Image.open(p)as im:
   wh=im.size
   if p.parent.name in {'replica','reassembled','foundation-review'}:assert wh==(1280,720),(p,wh)
   if p.parent.name in {'compare-replica','compare-reassembled'}:assert wh==(2560,720),(p,wh)
   if p.parent.name=='compare-threeway':assert wh==(3840,720),(p,wh)
   im.verify();sizes.append({'file':str(p.relative_to(tr)),'width':wh[0],'height':wh[1]})
 assert len(list((tr/'reassembled').glob('*.png')))==COUNTS[n]
 data={'collection':n,'renderGate':current,'elements':len(leaves),'fixtures':len(list((c/'elements').glob('*/fixtures/*.html'))),'pages':COUNTS[n],'sizeSheets':len(display)*2,'foundationPageExamples':len(list((tr/'foundation-review').glob('*-light.png'))),'libraryPDFPages':len(display)+len(list((tr/'foundation-review').glob('*-light.png'))),'sourceComparisonSheets':len(list((tr/'sheets').glob('*-replica.png'))),'pngs':sizes,'gaps':sum(x['use']=='unexpressible'for x in json.loads((tr/'map.json').read_text())['instances'])}
 (tr/'image-validation.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));zips=[zipdir(tc,OUT/(n+'.zip'),n),zipdir(tr,OUT/(n+'-review.zip'),n+'-review')]
 return data,zips
def main(names):
 OUT.mkdir(exist_ok=True);freeze();all_records=[];all_zips=[]
 for n in names:
  x,z=stage(n);all_records.append(x);all_zips.extend(z);print(n,x['elements'],'elements',x['pages'],'pages',sum(v['bytes']for v in z)//1024**2,'MiB',flush=True)
 previous={x['collection']:x for x in json.loads((OUT/'delivery-validation.json').read_text()).get('collections',[])}if(OUT/'delivery-validation.json').exists()else{}
 previous.update({x['collection']:x for x in all_records});oldz={x['file']:x for x in json.loads((OUT/'delivery-validation.json').read_text()).get('zips',[])}if(OUT/'delivery-validation.json').exists()else{};oldz.update({x['file']:x for x in all_zips})
 result={'round':5,'collections':[previous[n]for n in NAMES if n in previous],'zips':list(oldz.values()),'allZipIntegrity':'pass','totalElements':sum(x['elements']for x in previous.values()),'totalPages':sum(x['pages']for x in previous.values()),'git':'No Git commands or publication in Round5; local delivery only.'};(OUT/'delivery-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 for fn in ['replica-freeze.json','replica-freeze-validation.json','ROUND5-BRIEF.md']:copy(B/fn,OUT/fn)
 shutil.copytree(B/'tools',OUT/'tools',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 for n in names:shutil.copytree(B/n/'build',OUT/'build'/n,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('names',nargs='*',default=NAMES);x=a.parse_args();main(x.names or NAMES)
