"""Verify every final PNG, including sheet sizes and page/comparison dimensions."""
from pathlib import Path
from collections import Counter
import json
from PIL import Image

OUT=Path('/workspace/work/round5-delivery-20261025')
def main():
    rows=[]
    for p in sorted(OUT.rglob('*.png')):
        with Image.open(p) as im:
            size=im.size
            im.verify()
        parent=p.parent.name
        if parent in {'replica','reassembled','foundation-review'}:
            assert size==(1280,720),(p,size)
        if parent in {'compare-replica','compare-reassembled'}:
            assert size==(2560,720),(p,size)
        if parent=='compare-threeway':
            assert size==(3840,720),(p,size)
        rows.append({'file':str(p.relative_to(OUT)),'width':size[0],'height':size[1]})
    pages=[r for r in rows if Path(r['file']).parent.name=='reassembled']
    assert len(pages)==88,len(pages)
    result={'passed':True,'totalPNGs':len(rows),'reassembledPages':len(pages),
        'sizes':dict(Counter(f"{r['width']}x{r['height']}" for r in rows)),'files':rows}
    (OUT/'png-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('All PNGs verified:',len(rows),'reassembled pages:',len(pages),flush=True)
if __name__=='__main__':main()
