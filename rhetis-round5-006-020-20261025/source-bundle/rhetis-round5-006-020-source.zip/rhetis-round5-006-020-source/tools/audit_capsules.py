"""Actual browser alignment check for pill label groups at minimum and12x6."""
from pathlib import Path
import argparse,json,re,hashlib
from playwright.sync_api import sync_playwright
from size_review import paths,assets,document,wrapper,MIN_RE,browser,serve_url,source_hash
JS=r'''()=>{let out=[];for(let host of document.querySelectorAll('.pill[data-el]')){let box=host.querySelector(':scope>.parts')||host,br=box.getBoundingClientRect();if(!br.width||!br.height)continue;let name=box.querySelector('.name');let rects=[];for(let node of [name,...box.querySelectorAll('.mark,.icon')].filter(Boolean).filter(node=>!name||!node.closest('.mark')||getComputedStyle(node.closest('.mark')).position!=='absolute')){let r;if(node.matches('.name')){let q=document.createRange();q.selectNodeContents(node);r=q.getBoundingClientRect()}else r=node.getBoundingClientRect();if(r.width&&r.height)rects.push(r)}if(!rects.length)continue;let x0=Math.min(...rects.map(r=>r.left)),x1=Math.max(...rects.map(r=>r.right)),y0=Math.min(...rects.map(r=>r.top)),y1=Math.max(...rects.map(r=>r.bottom)),dx=(x0+x1-br.left-br.right)/2,dy=(y0+y1-br.top-br.bottom)/2;out.push({key:host.dataset.el,label:name?.textContent.trim()||box.getAttribute('aria-label')||'icon-only',box:[br.x,br.y,br.width,br.height],offsetX:+dx.toFixed(2),offsetY:+dy.toFixed(2),singleLabel:!box.querySelector('.note,.kick,.fig'),centered:Math.abs(dx)<=3&&Math.abs(dy)<=4})}return out}'''
def run(n):
 w,c,r=paths(n);assets(n);records=[]
 with sync_playwright()as pw:
  b=browser(pw);page=b.new_page(viewport={'width':1280,'height':720})
  for f in sorted((c/'elements').glob('*/fixtures/*.html')):
   s=f.read_text()
   if not re.search(r'''class\s*=\s*['"][^'"]*\bpill\b''',s):continue
   m=MIN_RE.match(s);mins=[tuple(map(int,x))for x in re.findall(r'(\d+)x(\d+)',m[1])]
   for cols,rows in list(dict.fromkeys([(12,6)]+mins)):
    probe=r/'probes/capsule-check.html';probe.write_text(document(c,wrapper(s,cols,rows,'light')));page.goto(serve_url(probe)+'?case='+hashlib.sha256((s+str(cols)+str(rows)).encode()).hexdigest(),wait_until='load');page.evaluate('document.fonts.ready');page.evaluate('([c,r])=>{let e=document.querySelector(".body").firstElementChild;e.style.gridColumn="1 / span "+c;e.style.gridRow="1 / span "+r}',[cols,rows]);page.evaluate('()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))')
    for row in page.evaluate(JS):records.append({'fixture':str(f.relative_to(c)),'size':f'{cols}x{rows}',**row})
  b.close()
 result={'collection':n,'sourceSHA256':source_hash(c),'checks':records,'reviewCandidates':[x for x in records if x['singleLabel']and not x['centered']],'method':'Loaded-font DOM text range union with inline icon/mark bounds (separately positioned medallions excluded), compared to its own drawn .parts box;3px horizontal/4px vertical tolerance. Multi-part captions are reported separately; this complements visual review of glyph ink.'};(r/'capsule-alignment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(n,len(records),'pill cases',len(result['reviewCandidates']),'review candidates',flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('names',nargs='+');x=a.parse_args()
 for n in x.names:run(n)
