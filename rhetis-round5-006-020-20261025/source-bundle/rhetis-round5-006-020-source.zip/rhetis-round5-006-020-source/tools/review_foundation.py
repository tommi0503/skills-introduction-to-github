"""Review optional cover/seat foundation fixtures at their actual1280x720 page size."""
from pathlib import Path
import sys,json,re
from playwright.sync_api import sync_playwright
from size_review import paths,assets,document,MIN_RE,browser,serve_url,AUDIT_JS,source_hash
JS=r'''()=>{let root=document.querySelector('.slide'),texts=[],pairs=[];for(let e of root.querySelectorAll('*')){let s=getComputedStyle(e),r=e.getBoundingClientRect();if(s.display==='none'||s.visibility==='hidden'||+s.opacity===0||!r.width||!r.height)continue;for(let n of e.childNodes)if(n.nodeType===3&&n.textContent.trim()){let q=document.createRange();q.selectNodeContents(n);for(let r of q.getClientRects())if(r.width&&r.height)texts.push({e,r,text:n.textContent.trim()})}}for(let i=0;i<texts.length;i++)for(let j=i+1;j<texts.length;j++){let a=texts[i],b=texts[j];if(a.e===b.e||a.e.contains(b.e)||b.e.contains(a.e))continue;let w=Math.min(a.r.right,b.r.right)-Math.max(a.r.left,b.r.left),h=Math.min(a.r.bottom,b.r.bottom)-Math.max(a.r.top,b.r.top);if(w>3&&h>3&&w*h>15)pairs.push({a:a.text,b:b.text,width:w,height:h})}return pairs}'''
def run(n):
 w,c,r=paths(n);assets(n);out=r/'foundation-review';out.mkdir(exist_ok=True);cases=[]
 with sync_playwright()as pw:
  b=browser(pw)
  for f in sorted((c/'foundation/fixtures').glob('*.html')):
   if f.stem.startswith('panel-'):continue
   for mode in ['light','dark']:
    body=MIN_RE.sub('',f.read_text());m=re.search(r'class=([\'"])(.*?)\1',body);classes=m[2].split();classes=[x for x in classes if x!='dark']+(['dark']if mode=='dark'else[]);body=body[:m.start(2)]+' '.join(classes)+body[m.end(2):];p=out/(f.stem+'-'+mode+'.html');p.write_text(document(c,body,mode,title=n+' foundation '+f.stem+' '+mode).replace('../assets/','../assets/'));page=b.new_page(viewport={'width':1280,'height':720});page.goto(serve_url(p),wait_until='load');page.evaluate('document.fonts.ready');page.evaluate('()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');a=page.evaluate(AUDIT_JS);a['overlaps']=page.evaluate(JS);a['fixture']=f.name;a['mode']=mode;page.screenshot(path=str(p.with_suffix('.png')));cases.append(a);page.close()
  b.close()
 result={'collection':n,'sourceSHA256':source_hash(c),'cases':cases};(r/'foundation-page-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(n,len(cases),'clipped',sum(bool(x['clipped'])for x in cases),'overlap',sum(bool(x['overlaps'])for x in cases),flush=True)
if __name__=='__main__':
 for n in sys.argv[1:]:run(n)
