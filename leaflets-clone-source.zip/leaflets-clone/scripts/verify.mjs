import {createServer,preview} from 'vite'
import {chromium} from 'playwright-core'
import {mkdir,writeFile} from 'node:fs/promises'
import {auditPage} from './browser-audit.mjs'
const capture=process.argv.includes('--render')
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH??'/usr/bin/chromium',args:['--no-sandbox']})
const dev=await createServer({server:{host:'127.0.0.1',port:0},logLevel:'error'});await dev.listen()
const page=await browser.newPage({viewport:{width:1280,height:720}})
let prod
try{
 await page.goto(`http://127.0.0.1:${dev.httpServer.address().port}`,{waitUntil:'networkidle'})
 const {brochures,missing}=await page.evaluate(async()=>{const m=await import('/src/registry.ts');return{brochures:m.brochures,missing:m.missingImplementations}})
 await dev.close()
 if(missing.length||brochures.length!==26)throw Error('Incomplete brochure implementation')
 prod=await preview({preview:{host:'127.0.0.1',port:0},logLevel:'error'})
 const base=`http://127.0.0.1:${prod.httpServer.address().port}`,errors=[],issues=[],screens=[]
 page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>errors.push(r.url()));page.on('response',r=>{if(r.status()>=400)errors.push(r.url())})
 await page.goto(base,{waitUntil:'networkidle'})
 if(await page.locator('.brochure-card').count()!==26)throw Error('Gallery card count')
 if(await page.locator('img').count())throw Error('Image in gallery')
 if(capture)await mkdir('renders',{recursive:true})
 for(const b of brochures){
  for(const [mode,list] of [['page',b.panels],['side',b.sides]])for(const sheet of list){
   await page.goto(`${base}/#/${mode}/${b.id}/${sheet.id}`,{waitUntil:'networkidle'})
   await page.locator('[data-fonts-ready="true"]').waitFor();await page.evaluate(async()=>{await document.fonts.ready;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))})
   const audit=await auditPage(page),unexpected=audit.issues.filter(x=>!x.expectedClip),key=`${b.id}-${sheet.id}`
   if(unexpected.length)issues.push({key,findings:unexpected})
   if(capture)await page.locator('[data-page]').screenshot({path:`renders/${key}.png`})
   screens.push({key,size:audit.size,unexpectedFindings:unexpected.length,chipCount:audit.chipCount,fontChecks:audit.fontChecks.length})
  }
  console.log(`${b.id}: checked`)
 }
 if(screens.length!==202||errors.length||issues.length)throw Error(JSON.stringify({screens:screens.length,errors,issues}))
 await mkdir('review',{recursive:true});await writeFile('review/source-verification.json',JSON.stringify({status:'passed',checkedAt:new Date().toISOString(),totalScreens:202,pngSize:[1280,720],runtimeErrors:errors,issues,screens},null,2)+'\n')
 console.log('PASS: 26 brochures, 202 screens; actual fonts, text bounds, chip centering, size and no image assets')
}finally{
 await browser.close();await dev.close();if(prod)await new Promise(r=>prod.httpServer.close(r))
}
