import {useEffect,useState} from 'react'
import {brochures} from './registry'
import {PageFrame,Thumbnail} from './ui'
export default function App(){
 const [route,setRoute]=useState(location.hash.slice(2));useEffect(()=>{const update=()=>setRoute(location.hash.slice(2));addEventListener('hashchange',update);return()=>removeEventListener('hashchange',update)},[])
 const [mode,id,pageId]=route.split('/'),brochure=brochures.find(b=>b.id===id)
 if(mode==='page'&&brochure){const page=brochure.panels.find(p=>p.id===pageId);if(page)return <div data-brochure={id}><PageFrame page={page}/></div>}
 if(mode==='side'&&brochure){const page=brochure.sides.find(p=>p.id===pageId);if(page)return <div data-brochure={id}><PageFrame page={page}/></div>}
 if(brochure)return <><header className="toolbar"><a href="#/">← 전체 목록</a><h1>{brochure.title}</h1><a href={`#/brochure/${id}`}>접지면 보기</a><a href={`#/unfold/${id}`}>앞·뒷면 펼치기</a></header><div className="page-grid">{(mode==='unfold'?brochure.sides:brochure.panels).map(p=><a href={`#/${mode==='unfold'?'side':'page'}/${id}/${p.id}`} key={p.id}><span>{p.id}</span><Thumbnail page={p} width={600}/></a>)}</div></>
 return <main className="gallery"><h1>리플렛 UI</h1><p>리플렛 26종 · 접지면 150페이지 · 펼친 앞·뒤 52장 · 1280 × 720</p><div className="brochure-grid">{brochures.map(b=><a className="brochure-card" href={`#/brochure/${b.id}`} key={b.id}><header><strong>{b.id} · {b.title}</strong><span>앞·뒤 보기</span></header><Thumbnail page={b.sides[0]} width={400}/></a>)}</div></main>
}
