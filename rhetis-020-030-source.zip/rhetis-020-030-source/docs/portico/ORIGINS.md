# 요소별 출처

| 폴더 | replica 페이지 |
|---|---|
| agenda--ruled-column | 02 |
| card | 03·04·05·06·07·10 |
| chart-bar--paired-growth | 09 |
| chart-bar--paired-projection | 13 |
| chart-donut | 13 |
| concentric--overlap-ellipses | 06 |
| flowchart | 08 |
| headline | 06·07·08·11·13 |
| image-frame | 05·07·08 |
| image-frame--wide | 03·04 |
| list | 10 |
| metric | 09 |
| metric--ask | 13 |
| person | 12 |
| pill | 05·07 |
| positioning | 10 |
| prose | 06·11 |
| tag | 07 |
| timeline | 11 |
