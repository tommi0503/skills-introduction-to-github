# Rhetis 020–030 소스

7개 컬렉션의 키트·foundation·요소 CSS와 JSON·HTML fixture, 디자인 문서입니다. 각 컬렉션 폴더를 Rhetis에 개별 반입합니다.

컬렉션: tide-tab, cutfield, filament, portico, toggle-grid, lamella, rulemark

요소107개와 foundation7개를 포함합니다. docs/에는 지도와 출처·검수 기록이 있고, contract/type-steps.json은8–256px 타입 토큰입니다. 글꼴은 Rhetis의 레퍼런스 글꼴을 사용합니다.

구성 파일은.css/.html/.json/.md뿐입니다.
