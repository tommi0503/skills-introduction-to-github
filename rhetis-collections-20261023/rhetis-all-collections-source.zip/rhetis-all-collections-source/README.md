# Rhetis 전체 컬렉션·복제본 통합 소스

5개 컬렉션(각56요소), 원본96장에 대한 replica HTML96개, 라이브러리 조립 HTML96개, 실행용 폰트·아이콘·스타일, 라이트·다크 라이브러리 HTML, 계약과 미리보기 도구를 묶었습니다.

## 실행

압축을 풀고 이 README가 있는 폴더에서 실행하세요.

```sh
python -m http.server 8000 --bind 127.0.0.1
```

브라우저에서 `http://127.0.0.1:8000/index.html`을 열면 각 덱의 모든 replica·조립본과 요소 시트로 이동할 수 있습니다.

## 구성

- `fluxweave/`, `cyanloop/`, `roundrise/`, `nightchamfer/`, `glasspulse/`: kit·foundation·전체56요소·fixture. Rhetis 반입 대상은 각 컬렉션 폴더입니다.
- `<collection>-review/replica/`: 원본을 재현한 HTML·CSS와 필요한 자산.
- `<collection>-review/reassembled/`: 해당 컬렉션의 foundation·요소로 조립한 HTML과 실행 CSS.
- `<collection>-review/library/`: 라이트·다크 미리보기 HTML과 공용 CSS.
- `<collection>-review/assets/`, `fonts/`, `replica/assets/`: 폰트·아이콘 등 실행 자산. 상대 경로를 유지했습니다.
- `reference/`: README 계약·taxonomy·palette·type steps·글꼴·preview.py·모범 fixture.
- `build/`: 제작·렌더·검수에 사용한 코드. 작업 환경의 `/workspace` 절대 경로는 실행 환경에 맞게 조정하세요.
- `element-review-pdfs/`, `slide-comparison-pdfs/`: 추가 PDF 생성 코드.
- `inventory.md`, 각 review 폴더의 `design-language.md`·`review-notes.md`: 범위·디자인 규칙·차이와 판단 기록.

시트 재생성 예:

```sh
python reference/tools/preview.py fluxweave reference/contract/type-steps.json --out light.html
python reference/tools/preview.py fluxweave reference/contract/type-steps.json --dark --out dark.html
```

이 ZIP은 코드와 실행 자산을 모은 소스 패키지입니다. 렌더 PNG·PDF와 개별 컬렉션 ZIP은 기존 GitHub 제출물에서 별도로 받을 수 있습니다. PDF 생성 코드는 해당 렌더 PNG를 입력으로 사용합니다. 기존 원본/카피 비교나 요소 디자인은 수정하지 않았습니다.
