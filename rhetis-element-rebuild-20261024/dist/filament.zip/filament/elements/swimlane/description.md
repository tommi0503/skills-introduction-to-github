# Inferred owner swimlanes

No source swimlane exists. Replica07 supplies 178x121 accent service faces,12 radius,25 light headings. The owner is a real full-width lane heading. Nodes retain their literal contract grid column and row, leaving the top40%of each owner row for its heading. Node faces occupy50%of the row height; direction connectors bridge the horizontal20%cell gap and vertical50%row gap. Two to five actual lane children control row count.

Two fixtures exercise two/three owners,three/four columns,all node states and all connector directions. Their honest minima are6x3 and8x4. No text or semantic fields are hidden.
