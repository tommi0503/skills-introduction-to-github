# Proportional flow

No Sankey appears in the replica. Page 05 supplies closed 1.3-stroke rules, inverse heading bands, and the 20/17 hierarchy.

A source-side distribution bus joins each ribbon. Labels occupy their own readable area, so a zero-share outcome keeps its name and figure without a fictitious band. Each terminal outcome receives one row-height unit. A direct band is 60% of that unit multiplied by its source share; a second split multiplies that thickness again by its local share. Every band in one diagram therefore uses the same value scale. Only the actual child count controls row allocation. No semantic field is hidden.

Verified minimum cells: `nested-4-2` 8x4, `routes-6` 6x4.
